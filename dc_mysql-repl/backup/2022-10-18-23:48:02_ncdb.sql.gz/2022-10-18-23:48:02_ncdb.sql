-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: ncdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oc_accounts`
--

DROP TABLE IF EXISTS `oc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_accounts` (
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts`
--

LOCK TABLES `oc_accounts` WRITE;
/*!40000 ALTER TABLE `oc_accounts` DISABLE KEYS */;
INSERT INTO `oc_accounts` VALUES ('atlas','{\"displayname\":{\"value\":\"atlas\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"address\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"website\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"email\":{\"value\":null,\"scope\":\"v2-federated\",\"verified\":\"0\"},\"avatar\":{\"scope\":\"v2-federated\"},\"phone\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"twitter\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"organisation\":{\"value\":\"\",\"scope\":\"v2-local\"},\"role\":{\"value\":\"\",\"scope\":\"v2-local\"},\"headline\":{\"value\":\"\",\"scope\":\"v2-local\"},\"biography\":{\"value\":\"\",\"scope\":\"v2-local\"},\"profile_enabled\":{\"value\":\"1\"}}');
/*!40000 ALTER TABLE `oc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_accounts_data`
--

DROP TABLE IF EXISTS `oc_accounts_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_accounts_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `accounts_data_uid` (`uid`),
  KEY `accounts_data_name` (`name`),
  KEY `accounts_data_value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts_data`
--

LOCK TABLES `oc_accounts_data` WRITE;
/*!40000 ALTER TABLE `oc_accounts_data` DISABLE KEYS */;
INSERT INTO `oc_accounts_data` VALUES (1,'atlas','displayname','atlas'),(2,'atlas','address',''),(3,'atlas','website',''),(4,'atlas','email',''),(5,'atlas','phone',''),(6,'atlas','twitter',''),(7,'atlas','organisation',''),(8,'atlas','role',''),(9,'atlas','headline',''),(10,'atlas','biography',''),(11,'atlas','profile_enabled','1');
/*!40000 ALTER TABLE `oc_accounts_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity`
--

DROP TABLE IF EXISTS `oc_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_activity` (
  `activity_id` bigint NOT NULL AUTO_INCREMENT,
  `timestamp` int NOT NULL DEFAULT '0',
  `priority` int NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `user` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `affecteduser` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `app` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `subjectparams` longtext COLLATE utf8mb4_bin NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `messageparams` longtext COLLATE utf8mb4_bin,
  `file` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  `link` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  `object_type` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `object_id` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`activity_id`),
  KEY `activity_user_time` (`affecteduser`,`timestamp`),
  KEY `activity_filter_by` (`affecteduser`,`user`,`timestamp`),
  KEY `activity_filter` (`affecteduser`,`type`,`app`,`timestamp`),
  KEY `activity_object` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity`
--

LOCK TABLES `oc_activity` WRITE;
/*!40000 ALTER TABLE `oc_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity_mq`
--

DROP TABLE IF EXISTS `oc_activity_mq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_activity_mq` (
  `mail_id` bigint NOT NULL AUTO_INCREMENT,
  `amq_timestamp` int NOT NULL DEFAULT '0',
  `amq_latest_send` int NOT NULL DEFAULT '0',
  `amq_type` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `amq_affecteduser` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `amq_appid` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `amq_subject` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `amq_subjectparams` longtext COLLATE utf8mb4_bin,
  `object_type` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `object_id` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`mail_id`),
  KEY `amp_user` (`amq_affecteduser`),
  KEY `amp_latest_send_time` (`amq_latest_send`),
  KEY `amp_timestamp_time` (`amq_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity_mq`
--

LOCK TABLES `oc_activity_mq` WRITE;
/*!40000 ALTER TABLE `oc_activity_mq` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_activity_mq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbookchanges`
--

DROP TABLE IF EXISTS `oc_addressbookchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_addressbookchanges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `synctoken` int unsigned NOT NULL DEFAULT '1',
  `addressbookid` bigint NOT NULL,
  `operation` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addressbookid_synctoken` (`addressbookid`,`synctoken`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbookchanges`
--

LOCK TABLES `oc_addressbookchanges` WRITE;
/*!40000 ALTER TABLE `oc_addressbookchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_addressbookchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbooks`
--

DROP TABLE IF EXISTS `oc_addressbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_addressbooks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `synctoken` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `addressbook_index` (`principaluri`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbooks`
--

LOCK TABLES `oc_addressbooks` WRITE;
/*!40000 ALTER TABLE `oc_addressbooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_addressbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_appconfig`
--

DROP TABLE IF EXISTS `oc_appconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_appconfig` (
  `appid` varchar(32) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`appid`,`configkey`),
  KEY `appconfig_config_key_index` (`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_appconfig`
--

LOCK TABLES `oc_appconfig` WRITE;
/*!40000 ALTER TABLE `oc_appconfig` DISABLE KEYS */;
INSERT INTO `oc_appconfig` VALUES ('accessibility','enabled','yes'),('accessibility','installed_version','1.10.0'),('accessibility','types',''),('activity','enabled','yes'),('activity','installed_version','2.16.0'),('activity','types','filesystem'),('backgroundjob','lastjob','9'),('bruteforcesettings','enabled','yes'),('bruteforcesettings','installed_version','2.4.0'),('bruteforcesettings','types',''),('circles','enabled','yes'),('circles','installed_version','24.0.1'),('circles','loopback_tmp_scheme','http'),('circles','maintenance_run','0'),('circles','maintenance_update','{\"3\":1665780897,\"2\":1665780897,\"1\":1665780897}'),('circles','types','filesystem,dav'),('cloud_federation_api','enabled','yes'),('cloud_federation_api','installed_version','1.7.0'),('cloud_federation_api','types','filesystem'),('comments','enabled','yes'),('comments','installed_version','1.14.0'),('comments','types','logging'),('contactsinteraction','enabled','yes'),('contactsinteraction','installed_version','1.5.0'),('contactsinteraction','types','dav'),('core','installed.bundles','[\"CoreBundle\"]'),('core','installedat','1665765832.9597'),('core','lastcron','1666121795'),('core','lastupdatedat','1665765833.1338'),('core','oc.integritycheck.checker','[]'),('core','public_files','files_sharing/public.php'),('core','public_webdav','dav/appinfo/v1/publicwebdav.php'),('core','theming.variables','b92d206521717ac032f8aa58d3c7ff2f'),('core','vendor','nextcloud'),('dashboard','enabled','yes'),('dashboard','installed_version','7.4.0'),('dashboard','types',''),('dav','enabled','yes'),('dav','installed_version','1.22.0'),('dav','types','filesystem'),('federatedfilesharing','enabled','yes'),('federatedfilesharing','installed_version','1.14.0'),('federatedfilesharing','types',''),('federation','enabled','yes'),('federation','installed_version','1.14.0'),('federation','types','authentication'),('files','enabled','yes'),('files','installed_version','1.19.0'),('files','types','filesystem'),('files_pdfviewer','enabled','yes'),('files_pdfviewer','installed_version','2.5.0'),('files_pdfviewer','types',''),('files_rightclick','enabled','yes'),('files_rightclick','installed_version','1.3.0'),('files_rightclick','types',''),('files_sharing','enabled','yes'),('files_sharing','installed_version','1.16.2'),('files_sharing','types','filesystem'),('files_trashbin','enabled','yes'),('files_trashbin','installed_version','1.14.0'),('files_trashbin','types','filesystem,dav'),('files_versions','enabled','yes'),('files_versions','installed_version','1.17.0'),('files_versions','types','filesystem,dav'),('files_videoplayer','enabled','yes'),('files_videoplayer','installed_version','1.13.0'),('files_videoplayer','types',''),('firstrunwizard','enabled','yes'),('firstrunwizard','installed_version','2.13.0'),('firstrunwizard','types','logging'),('logreader','enabled','yes'),('logreader','installed_version','2.9.0'),('logreader','types',''),('lookup_server_connector','enabled','yes'),('lookup_server_connector','installed_version','1.12.0'),('lookup_server_connector','types','authentication'),('nextcloud_announcements','enabled','yes'),('nextcloud_announcements','installed_version','1.13.0'),('nextcloud_announcements','types','logging'),('notifications','enabled','yes'),('notifications','installed_version','2.12.1'),('notifications','types','logging'),('oauth2','enabled','yes'),('oauth2','installed_version','1.12.0'),('oauth2','types','authentication'),('password_policy','enabled','yes'),('password_policy','installed_version','1.14.0'),('password_policy','types','authentication'),('photos','enabled','yes'),('photos','installed_version','1.6.0'),('photos','types',''),('privacy','enabled','yes'),('privacy','installed_version','1.8.0'),('privacy','types',''),('provisioning_api','enabled','yes'),('provisioning_api','installed_version','1.14.0'),('provisioning_api','types','prevent_group_restriction'),('recommendations','enabled','yes'),('recommendations','installed_version','1.3.0'),('recommendations','types',''),('serverinfo','enabled','yes'),('serverinfo','installed_version','1.14.0'),('serverinfo','types',''),('settings','enabled','yes'),('settings','installed_version','1.6.0'),('settings','types',''),('sharebymail','enabled','yes'),('sharebymail','installed_version','1.14.0'),('sharebymail','types','filesystem'),('support','enabled','yes'),('support','installed_version','1.7.0'),('support','types','session'),('survey_client','enabled','yes'),('survey_client','installed_version','1.12.0'),('survey_client','types',''),('systemtags','enabled','yes'),('systemtags','installed_version','1.14.0'),('systemtags','types','logging'),('text','enabled','yes'),('text','installed_version','3.5.1'),('text','types','dav'),('theming','enabled','yes'),('theming','installed_version','1.15.0'),('theming','types','logging'),('twofactor_backupcodes','enabled','yes'),('twofactor_backupcodes','installed_version','1.13.0'),('twofactor_backupcodes','types',''),('updatenotification','enabled','yes'),('updatenotification','installed_version','1.14.0'),('updatenotification','types',''),('user_status','enabled','yes'),('user_status','installed_version','1.4.0'),('user_status','types',''),('viewer','enabled','yes'),('viewer','installed_version','1.8.0'),('viewer','types',''),('weather_status','enabled','yes'),('weather_status','installed_version','1.4.0'),('weather_status','types',''),('workflowengine','enabled','yes'),('workflowengine','installed_version','2.6.0'),('workflowengine','types','filesystem');
/*!40000 ALTER TABLE `oc_appconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authorized_groups`
--

DROP TABLE IF EXISTS `oc_authorized_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_authorized_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `class` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admindel_groupid_idx` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authorized_groups`
--

LOCK TABLES `oc_authorized_groups` WRITE;
/*!40000 ALTER TABLE `oc_authorized_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_authorized_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authtoken`
--

DROP TABLE IF EXISTS `oc_authtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_authtoken` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `login_name` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `password` longtext COLLATE utf8mb4_bin,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(200) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` smallint unsigned DEFAULT '0',
  `remember` smallint unsigned DEFAULT '0',
  `last_activity` int unsigned DEFAULT '0',
  `last_check` int unsigned DEFAULT '0',
  `scope` longtext COLLATE utf8mb4_bin,
  `expires` int unsigned DEFAULT NULL,
  `private_key` longtext COLLATE utf8mb4_bin,
  `public_key` longtext COLLATE utf8mb4_bin,
  `version` smallint unsigned NOT NULL DEFAULT '1',
  `password_invalid` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `authtoken_token_index` (`token`),
  KEY `authtoken_last_activity_idx` (`last_activity`),
  KEY `authtoken_uid_index` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authtoken`
--

LOCK TABLES `oc_authtoken` WRITE;
/*!40000 ALTER TABLE `oc_authtoken` DISABLE KEYS */;
INSERT INTO `oc_authtoken` VALUES (1,'atlas','atlas','ClOoHkcRK/LXjbPjKisZi1iq6W6AyCjF2Bwto6cZlkmfoI1wsfvHxt33ayQ1eiKmybED4F4qX3dPBznI1AA4YZEwjUQPX0mlQj8BiVK2xqGC8G0F9g6edverL7SRUiMWBfQOZHHMo7AMDBtuie07uQOg6ErfDJzzQnzFTmw6DSgbfSWbkZx0WS6SNnPPnvWQv4aTdbKl2bSF0ZBPK9zMbQ/qYXxlDtOMN00CmjLXaMOItbG1sw21rWFTD3EO/AB00pmOTsBbg9XhlTMTlMI5h24L9sF34bBoWj18FKsYwi6A3VNXH4ttuP6uMsHV2/e0Kli5HqJQNG/JQKWpCFo6RA==','Mozilla/5.0 (X11; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0','0d625e51f7a1cc59fc3fcdbd999f01430d1196e2bcb9d7e4667c0d188b92945d125d1003e3080084510ecf3c3300bf2c60fcf752db9c950bd15b61adfb310bdb',0,0,1665767028,1665767025,NULL,NULL,'90fca52d481c548c070c852e07a5e4d08426ac6e8438bebe5b4ec4dcdbc09825bb7a0b88f1e5817cc2a737ad9e112611e12155d51701b79a0950a7e6f1a9a6f0b65402e72c2cc534c00d2dd2ea0136300efc6719990cea771298278e6b4106756cb95160d613a5d4f20ee7e180ad86887e2c79afb6ccfc5ffc3ff3e34d129cd17fa5c68f9582d29d9f116b33073cdae29c68db591699920f2dbdc8780dba047b03885658346301d713132ca9157bccc31750b5f54a0697936db5722010f92ce7ec57d9b9262ec377bb85b782b45d44bc769ac9b851d0f89e05953573efcf97a86c19242c9295e7eac94764add922d8f338cf3d5fb99feec624ae5c47357f15a599d10fd6b749b5cb95654b2cce10cb33d3e89c40f1dadad5a600c74367908a28a16dd71f14d0c73a93dc082f36418ca24e6ccaf1d3295d3b21ea9175329752ea3d0ede8a534a751aae353b8f5c5789480dc18b161079e5f666299edf073f86a3aa541fe0fe650f102af11cf87c42699369e3be897d65e5794f611e29ce39720ba510a0db1496115aa664f63528d291dc2aa177c037cbb8c09d6967937f995dc2c7ace5ba79ad13ea32235589938d02d96ba20a2d169626eab4286ec4006cf151d05749ff1c73b128584bf8a084a86c4b23a8c3628bbe1bfd612e0e2200ad7615a3e9ff467b3b122c0e82a121c9f5465b82ae06b9537bd155e25b99191af27d49752faf74ea6110446ef542c6e4f09f2d95e222ccaf683889c8f01662ecb960ba1ebb9f3edac0bde13052692df89c6ed8aad1bf8e73d21f8e9f5539a6572307e263ae1f64a6631e2bc2a988511e660d21d23ea03f6f5388efaf4c4629c00239f1fcbd6379d77d2f02683142e5baf689803aad29d49e0acca560a89c8aa5648570a4d709610e1ed7e27c7bb86b9bec13f45c803b3ef5ab08a30c4e6023f09a0cf6377b9a4055dc777ce873d5ea85a41fb6c64320dcc21d28061df9d088d859d7d0aa36b4db97637bede9f85bf105235be127a49dfbfc833bb2c37d956baf17b6274f84ff0f8eb226f3ccfaf82279e66930512d4d9f7275a4672992875d7b62b7ee3d609785391ef9a65bb163be054f7db03fa3517cd92fb86fbe7baeda0538b4cab7126422acf17d5da7f2d410114c982f63d9c98347e7040232cbe325c9306255fbf3666a1bdf046e90f20e2df97b3e1432730fce83296cd5417339057f64abf305e0019df68d70f72b2928cf8132498ab3949dc6123bf60c6be03cf8730326972d203e36d4fee813a0d8f241570306f36d415b72ece98f3c27cc6100d7b0b578d616fa2a126245e21f0c2d8e8a81454b561a40809c7488805e02e469081deb64078c906577118a185cc894a5f2fccf100ba3220fa36c99d3ae469fed1c13fa4118940b79939e5378821dd7887681776fd214cb641e0d374d30982f6ea9bff09e432c6b91f664250e0876225649641c1e09532e1aa82fb1875b54b31637d1865f2fcc6287cfddcca307507b11365689e22942c358bd51fcf6d68e62c7bf4969932aeab80c15cf5cd337e4f709fff9f3edb3f7bceefa2802189a1b3581b84ee9558ebb5558215b3e52372cdb3ab1e2e5d6d9af3fe65ffa3451899fa01447e48ac0bf29f1b6ff3cc56e84a18f0de40dc85dff08179a1459d5149bd619df3d3f57917cbe8cf17e9126f1505db919f64925d9df5c312ad72230a04f24193eb5e9f59989acf65ac9c0f6756466232ed810d5336c37dcf6d4d290a917630313de40f1b421dcc3227aa9ebc293ae5f1a5bdaa6d896d29d397efd7fe67d6639602613db02298f50c7798b0ac9d32ae684aa73af518bdced81e52a87e4807b9dbb91462b6a6c070adb34d5e2de8bc76398ee388ddbc4f2ea46012baf51ca9b100f99ecca4ef96fafb7d2d609a7e6f92cdf6d7da13a6a907b60e37e30b8116fe3f81292f4345d8d5766ccb3d423f0dbd132f0113626b264a2fdd840152b01971c8092f3d4465468a077cccafc4dac6ee8289214d63155876a255fcaafb54555ab25f94f0fd3d450d3fce267af045d72019539d332fe1dd6e100f1713f40f447f23ba939026da9cff5fe81c944a05ddf7e8cb4572cb5786cec6a39f22ddc500290ee327252b77c6f279109db5b0918fe220eae3dd8fb5e7fe807c48eeb27759de52529db361c50f2eaa64d692749f84bf421f22aa076b6bfbcd28d679242c98daa9326164924046f2a43e19444fd521dd4e48374e480749e82bd743f7176793f87ddabc60c2bd6fdc8f21fd921302fc4668278c7448ccfbb2fed393399de3920f2929af87d212af8ddbea2b92bb526749315b35842b604a04727d9a59d93a7bbb249e2697d56192fd7bad1ae314f062dc1ed8121795fc81a8d8f394a9e0828b69ade527d21f0f1428064a368190d357edb18cd055bcf|f751eb6cb0d875ae912846e3af821573|b27f3712789198c809c5be9211203b2c47dd01c98616cfdf0a2d0fb026fadeae7f18a44d66a6f31b48e1c399387cb52589c6e9f620dd1d1ef2fdaa378326745f|3','-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6ak6+4WOjjIX0pVxwPug\nLyIyxnrMFG13oqdEyd7gOaqc/nBK7qIPsmzMLImsMD4+l7fhF2Hrz/ZJNLyLdb7r\n5eH2EwCy86PUN8/xUrP6qb9cbRJ7o/qmMRw34Vl5UqwKQHrd3ZvyJ9qw5/5EOsof\noVh4s9twYUKrKulO3x/sURFLPyeAbohtVrAxQqlDLVnUDjD+OujUamm1eWFedOlp\nDlDT13C2tqLDf4M8PQ3vHwdgDOLgkhHl5G+mE7xlevhEbU5/DD9O/Dcwfe2pLBG8\niJ2KDOH2o9Nqh1jI8yc6AKwSxNwVIR+bItvo7DW3CCkebH4fXreHjwNLthgAIa/j\nlwIDAQAB\n-----END PUBLIC KEY-----\n',2,0),(2,'atlas','atlas','T5AGEd2UTANbWA86WqOvzl0tto4oHYkhw+exDD/NQA6Qsv7uUE5mrZr5GC4Qmfh05DlzUEgV4ovAxX6PxljbvcIbGFuqYb+/YlfryILpicpM+R8TBiPLxB9uFmnMZNXQgSxyLI5nMgpa1Dce8Q7bE7tNILc70LyXXoghrinS9reG4BFHUF+dcbSe1Y2rinTcSL1e/S51c/hiGChvbLtnND2p1okpZrVudKhUnbiXK27d2gwVv5aefiIohUX9cVZDwrpQjvYKHyBbo/+M9kU+0RDkYdZUTDF5jRKfTAQmtyi1rDYAdQRJXPvl7xk4/JDlRyFso93QOTG15z7DaV/mtA==','Mozilla/5.0 (X11; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0','d880765f8c1b27c461ab79efc6c3f9af306e95a3cb577782b72f65b8442b76ec50dd875d898a42d193106f62344a2de57f0a0a5ecd171ac8d789cd49b7637b0c',0,1,1529666682,1529666682,NULL,NULL,'c6c46643f55f6d6ff13236cd1706961afdd270c6de2bc8f62f179417b534960f66c35446361c51272784d28af24ae4ee9ac700f413446438d5cf3776fae025e1bac39ca918d22bc5000ace4d262a47b5cf4bbf82deeaf779938831983588f04fb8d803f3737cc3fbb9a9ee8c2c891ad75c7dd5aaf9c2cb4278dba259ffba425146956afc7f0ea43ca6a681467d618693761e12dfe72ddfa8972cb95da8df8187d1596c6eb9e89486ffd352575507f2757a17597d51548de30ab1f0c609f493243021bd8ae69e12161d7b0752637938db6479fe3c4d5aeb6b028b46ac33fb631a4e4494b168373019a3860a6f98f46c5df1222a0f901f0223a71331173c7ac7e2e7410e4203aa84d7aaff41c1b4c0a95ed5aae0c36d08928bc5810b1df1820ed616469cc616c00c411aee646bab98697b7316697a95559ec6c253319453f0aab4b87f21d41537c1d66f311039a7286f4e1b5ca288416b72fbe9f64bd534f490a4631f4c7fe2e707d56da50045e8f20c383213680ab300a4f63f3802abc45c688e3f199182b34d2b9c026f8ec8b49aeee10f3d5987daf50eef0fee1c8c1a7b1e71b568f577e5243a25d5c52f1f8893218f9318aee06813c13046156dd7160939be5ed5544b3fb98693cbcded3f6fc9475a91e6b6dee0ee59d1a975031151406bebbc94ecded2e82b31479c2eb164e5480877d784d25944ded56c0c7af8892dcec626306f398083b1ac56b73acb350dafe4ba683d97d7f7226a6c0e59315ae03ae99ba653ee46ab36f4209c9a046a4d6d6ded4df48e53fd2c5838239abafa36f07af2a7ab0196c863e55af7103a7eab3eb400382936a56c4d540194e20540b39e3b56f6010908f177c719ed0e04094a5a139b3d1ba12e238bea3c894d7bd48461ec1d128a04c9ade82fc3ced5dac0eaa675c181d0b5783842c52f18e412c3c113fdb12dd3e480b7eb44286f1ded7840c678b3d7806eb2b42af9befb8963bd080175c470538c439fa29a868bf0829220730d72fab52eb70febecaf480c76503f88fd31e8a91967ff56208a879cdd16c14037b450069cab3a7dd75115fb2fb3c086b25730967c80fd9d795d816d9f77ab2568989111f4da257117161da8ca6f1d6495fe8a4ecc99de1d4c2a8876e5c3e253a07650b70097d1c87b37bc76087914480e64e06d8b2940213acb1316406637b661b598ec3faaaeb94910dce8ce5814c67a635c6f5df1bcd5d1d45d7b86769bac6d1779af7a024663108171daab652cf5304be1808bf32bc9d4399c1a38f480ac4ae8c1f754d4388f268f5b5ae761ea1c856a997e4a5560b16545d692ad18d0e9c012697c7283b1e68382a37374844a765daf37c05370e1b8f49b567a867dc0a2d1a144b165369bc11ee87215b3cec10aff73aae75222c00ee0cb4c02106a48c7f8b2581875eae805484b0955495d5ee58b0d81e137955493199492383d470bcf47309ba073dbccbd6640177d6f6e5e4c36ee3dd63884a9f4906a4e0892ce72abda41c08694515829881891e651922189b70ffc8a0d5146b534e0fb54ca01310c1b53d07e14896756929caba7cec4786f6a8ee2e2c93d81e1056fdbf458f4233c0db04fd57897e4bddf42e8ffa6ee95fda096db2f15cf5ba1d62714dfc20f0dad2433859cad794f49c7e1092f74f656c4f672488e4996fdfc829d39aeafa964c9d0e01209c4bb57526bb2a8a238dc941a37cdec3e573183b4fe61e725fa71ce8eaec56e066f4ec7d3d0e63167c9b5633255aaf963002dc53c52d6937dea64ecf685da4d941d081b0ad6966cb5c200400c8e0127e7c348f869f7484582241220a67eb9f229b8371c607a6a78b1a6d613a61b52733b0eb54a56f00e19ffe0c1bed0e8cb410b0709eee0d160f5fea215b4df9d96e593b2ecebd7973439f654dceeb6797f5b1346b2662b169b186c35c11ef7cf7709d5b347d80e86bdef2cc2ef4a1b13d8bbf76ce04bfdb794a21829145f77d9c77264cbcd22101d66f186a38646ad580d4b0002288190c3043432b7fb2056abcf31833b602acc2e7dde5c833a1f35545b6b0a25e637aeca07a92a2b7ae7f9b013c692f2d2ba85f9ca60d53dc3a2e5529ee802a6b1daf615c3e0111aabc068144ff3168e9ae45f9e8a7fc10d08eae89eff5819913a7c3ef6575e77e7e117efd83ce5969c7cee7bc42fb6c6a6bb556dcd1e24956621aa11b85c4bf6ca6fb153f19962f7017aa0a913e9e8bcc9f506ca8486d35d8a159886b62c8aa37dd75f9d2f810279f62fa8d7eb42f3c554933c3bf94703926a62acb850e557da26f7022a4784f3610d3ef6111a97a753d722a307b40f77c7639dc87e1c3c58df84c87a904e52b12a65ac9b88545a5299b595a2e7b20608a0db071d30ec7857957e175f777c806ae90bfad7dddeb52210907027006b|93bfd10e58a08d20329ed41e930b9039|7b2f3c2b19355260efe31eb6e6a9ba54f8899bf452b6565909227d69b1cc3db46a07f0c92d17ef27cbeba3f4e0889cda8b30a8a6fa92bb609f6c7b2a950bf45f|3','-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApSJJdS4G/FcdDUQIX/oe\n6P/UK7o60f0kX7g0m9bY4i1HYKENhkbtSa9yW06F1CXPpaSL5zJkftXLi5Zvvbzm\nmCIQLAgL1a46h92FSck9Xja6H9lu6lKOLAM76Uaxnnt4Kv2clAuRbJw3oPThKC8R\nwflG9MTFIuytuBszFpjtWLkSzDOOb/25UyFcaq3L6vK/mOWYcBa6YcLDtXtXGoqi\n1QWlEW5UlhRwpXdhTgwz8JwSwELdE8/BbM2R9MjxI/EjarlZYOfgZOfvJWhKuUoG\nVR4pJrSoOmtQqXW9F3/WHOcdJZuh5Nuv0ztiGrHGNHK5V2sXc2XU1XJF0wuIbpIc\n/wIDAQAB\n-----END PUBLIC KEY-----\n',2,0),(5,'atlas','atlas','SF36N31NJ9uygfRbDXgmR8e23uq+db3pxB2tT+D92ZoLIK3zvpkOcMJzpRhPI5jcNSufx9WojFQObe6qOEtJ+zFyVuTwF+oisBE3lMDMJjnukjMKGvuv3vCj4UUQ3aQavcX9ZrgWIYwJzSiEzOcT051UAX8Bm6hmrxDBfUX58mKhDKf9faHHMGmozIEaR52+PVELqoe7BTa5cpVu/6gRDd9HU6J74jrLM5jspQ6DkwrkbmI+gonXQ9QQL0uMKUUGKdS1VsdamXXs3Z6pvH1CFnQSCZ6jOg78SxPacGUsOwNuA6/8Fd4Mio93TWZIk8gV+866D3930HDdHYaWMLfa0Q==','Mozilla/5.0 (X11; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0','097e8e963b59f07ebb7a1191510e1fc4520c0be365acbdc483021f2f1149ad1aff35d0805a85b731c0a55dba210154a5cf71062cd5fe270c62d3ebba749b7b90',0,1,1666126053,1666125993,NULL,NULL,'ab512373de6f1d88f475f8d7ccb2ec6025ae8bf85b70cd05c660b31f0b118d4e0a9fd16880ddf56b9aff91c297b4cd0afc2c980fbf81f984364c8f0ce6e65014b22c63a9b5aab1eb290a4d73d21b6416f4bcf7517ecb49a29d0c4cd609e5e17064e3d98868963ee44181171975da86255419329eb368243ef78b3757702ccf764a455c493ecd314201dd0cbccc226c51c2ad99b3c3a1f9dc8509c03a1c0aea09de9d06174a495083c937764e093c856abd786719a994c2168ac3c237d24572f14a830a26d91fed81926da00433ff80d880055a0e3181b9de76379f34c254bebdb63fecf38a75e2347e9fcd5b87bd6db84cc25155e9107e0fd96ca4837c50f454ef944795b48cc91af2429ef98b50658bba6e7fcec0ac47b986b6ad272840258c31546acd4ec33a21aae5267267ea8bd42ce793c15a3d269fe201d14b5bdf8e120550578905e1ba02b36d0af91425339b97fa29e818846257fb408cacdaa70aeeb0fff0eb1802c609100ea8b5307a8cd0b9ce1ac9cf95312a0f815fd29992f8a9c10bce3705e45b43c2d454a40788ec67f373959afe605b94fd3ebe18782f948e525c91e56e7e1e82330d5f0676785de39662b381d4d972ef0ed3df5e8bc2a9399d1a17eb01f4d3726b4e5916bd2c3b3d7e11fde0adfb3457e82d23a243eccb9807a698ef2184c44bac76a3d069d3f6cb571142560e366451d7ae0a0c7e018677965bf17b64507fedf8a43459e35d59003a9b94385189b704ff82f5a890f178d28363e14fcd4ee79e87495dd1624b3e0ea105338203b99fc10661c99fc26d6e2db3418c23603556d9197bdf585248d6ef3b51b28e39f12942475cd1b82cfc2bfeff775a480cf396785c5ee54bed71006d45dcc88a21105a71af53d896052dcd4e35e6e5760b79e60b2ada4ed5d70203c4f995613e0db438c94dccdba1259973fe4de077cf6969573404bb93739b95dccee51dbd0d3fa8b7075ed76d40f1288cefd3f482f13011397e3382b1320bbf6e732de9b8d05d57e50ca8f121bbbcee31c261b18103c0672d9d23de0b2064cbe942cf8f6395367e0d6daa52321cc897e3da52fd30e7e724cf6525f353f8c8f8a977829eec8e2bdb2001186929a365d7602c063c3d574c135eb4bcf79b7c3eb9a6ee795adf96f4c0e36741a31908f94f6b44d836980cfcfc9af0df0e3040366b11f0ce4ec4eedb25500b4384f356ca0a34c85d662c557d97259ce8764aa171d7f7c21627e1a709391dfe95344c411f8db8b5d1ec612fec083a1239fc9e88e6c69676cb937ea97747b0e8b33beb3d35f257080c38d2067e42c246cf8ba4422cbbff593d48c0462ee50279a5d7bb6ade4d5207c16dafcae1b1e5105b15ce74918ba2e7303da91590fcdd5f8daec313e2b94727f3d6f53a5d05962c8f687a9b8fa3ab3c89d1ceee94c786635b24dd5b58c89e4f927e9c93e0417b571837bbc4fb193d23258b9d80e2ece15ec4cf7b16be7041e2017bb674a57cc089378e5712747bb746815bfee0f00fdaa22a874dbc9a50ec69c19b0e7685e33a4c1ef710eb376f1c2e724922c7d7df0bc11e02c15bd9c2940bb022ae683850929da8e8c95a0ba72e873d5c4000ae07225098c886c90276526e7d3adab2256d3313870a627ac9d8349069df8d3b20e6a25f27162254494112a05233db26c0f2c73c6a6a9c6a23c65af692443a7a7ad2e6f7db5d71ed3206ae7650d645ff4cc74276cb5e31851a1548a5027431a4da7874b9bb2793b30063b3bb073b5faf1b3641c2bcb6f742c4071b7c59e253d7f43dee4ff17b10fb320f3bc00854f8d50b4a79ad08d6f29b57b081983e66dc874f130793c9ffce8a9e6a865069c8b2b5c63b89d7f96deb90b2fd34333cce343e41ce7806d088ef151f4e6647604318540a4ea3e32c7ac532c601f4d06ff249416a633a078930be43510f57a03bfd4eff031ea620ce4070bdc44d64234b886d22c206d50b438c1f9a2974f7eee2e471bbb2f7ce8ea67d8627d92ba10b93df8959367a75d259ebe9e9af90f6eeca2812e9d078afd77bbde3d9c6599dfb9ae67aea927c5abaee0313ecd893e92f26415ecac837cfa029a1b3043adb48e81453afccbcda3149cf82e830ed79617ae833a34fbdf057bab6445ff7d718f7883af38f422c9c02510525dc922e74ba2707c6ed6fa0b6b9bfc2545c8bc40caca4a8e0131e7f8d762e3e4f7ffaffbab5a9643c3acb3fae23e215b23baf5c0be3c8170db185dc2d84071e03499477025091881e3eb90f1feca419e815f73412431909c1f7768e37af4a5dbe867a9513d4e5941fb8ed72a62676df4932c472c48859cfdc3841e490436bbf937c6580f8b4112279cbd979d3de646a6c61c28111649cdba383cf1075345c19719a59ee4138f1d8de7c6e3cb72ed2de6c93352c03f531|e51739c91800a96e1474d2a76a6c2d61|7681ac296e7a0a404625348089dd9079b25930ba5752cc3f7cd1e0d3ea6bf9125db9c7b8436aeae78ca08963a5984ef0393a97095adde75ba5d4d42fe865c3b6|3','-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwv9JGsOwaJ0KS2k3e7Ti\nbX6dwPjWyHfueiAWct4bHy1lliIR9uoKwub3X4KTLJ9Ajug1nqYz+qtuM2WXcH/0\n+Xzlo1a6R0CaEGTpqVVoWvX0jgKC1mz24AtFxiLtgZ3mAcVd+yvRONgJ2B8wW3qQ\n1m1iy/fYJk3mF3tjPrco8McVRXHh+WyjIFkXpzB8DqyCvHDlX90yyu6pITE5BlLj\noIh/2lOVpV9JxoybVGQcuztb89gyafhvnkocBxK538oelWmEe+8HN8So5J//ATcS\nV9Snu+gjj3hmZSVCkAvXna2zTtYme+8w2anCqx7oEXX1QFtJxc+SUXGVECOhKlo7\nOQIDAQAB\n-----END PUBLIC KEY-----\n',2,0);
/*!40000 ALTER TABLE `oc_authtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_bruteforce_attempts`
--

DROP TABLE IF EXISTS `oc_bruteforce_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_bruteforce_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `occurred` int unsigned NOT NULL DEFAULT '0',
  `ip` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `subnet` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `metadata` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `bruteforce_attempts_ip` (`ip`),
  KEY `bruteforce_attempts_subnet` (`subnet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_bruteforce_attempts`
--

LOCK TABLES `oc_bruteforce_attempts` WRITE;
/*!40000 ALTER TABLE `oc_bruteforce_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_bruteforce_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_invitations`
--

DROP TABLE IF EXISTS `oc_calendar_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_invitations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `recurrenceid` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `attendee` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `organizer` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence` bigint unsigned DEFAULT NULL,
  `token` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `expiration` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_invitation_tokens` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_invitations`
--

LOCK TABLES `oc_calendar_invitations` WRITE;
/*!40000 ALTER TABLE `oc_calendar_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_reminders`
--

DROP TABLE IF EXISTS `oc_calendar_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_reminders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `calendar_id` bigint NOT NULL,
  `object_id` bigint NOT NULL,
  `is_recurring` smallint DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `recurrence_id` bigint unsigned DEFAULT NULL,
  `is_recurrence_exception` smallint NOT NULL,
  `event_hash` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `alarm_hash` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `is_relative` smallint NOT NULL,
  `notification_date` bigint unsigned NOT NULL,
  `is_repeat_based` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_reminder_objid` (`object_id`),
  KEY `calendar_reminder_uidrec` (`uid`,`recurrence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_reminders`
--

LOCK TABLES `oc_calendar_reminders` WRITE;
/*!40000 ALTER TABLE `oc_calendar_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_resources`
--

DROP TABLE IF EXISTS `oc_calendar_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_resources` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `backend_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `resource_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `group_restrictions` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_resources_bkdrsc` (`backend_id`,`resource_id`),
  KEY `calendar_resources_email` (`email`),
  KEY `calendar_resources_name` (`displayname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_resources`
--

LOCK TABLES `oc_calendar_resources` WRITE;
/*!40000 ALTER TABLE `oc_calendar_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_resources_md`
--

DROP TABLE IF EXISTS `oc_calendar_resources_md`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_resources_md` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `resource_id` bigint unsigned NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `value` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_resources_md_idk` (`resource_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_resources_md`
--

LOCK TABLES `oc_calendar_resources_md` WRITE;
/*!40000 ALTER TABLE `oc_calendar_resources_md` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_resources_md` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_rooms`
--

DROP TABLE IF EXISTS `oc_calendar_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_rooms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `backend_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `resource_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `group_restrictions` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_rooms_bkdrsc` (`backend_id`,`resource_id`),
  KEY `calendar_rooms_email` (`email`),
  KEY `calendar_rooms_name` (`displayname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_rooms`
--

LOCK TABLES `oc_calendar_rooms` WRITE;
/*!40000 ALTER TABLE `oc_calendar_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_rooms_md`
--

DROP TABLE IF EXISTS `oc_calendar_rooms_md`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_rooms_md` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `room_id` bigint unsigned NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `value` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_rooms_md_idk` (`room_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_rooms_md`
--

LOCK TABLES `oc_calendar_rooms_md` WRITE;
/*!40000 ALTER TABLE `oc_calendar_rooms_md` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_rooms_md` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarchanges`
--

DROP TABLE IF EXISTS `oc_calendarchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarchanges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `synctoken` int unsigned NOT NULL DEFAULT '1',
  `calendarid` bigint NOT NULL,
  `operation` smallint NOT NULL,
  `calendartype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `calid_type_synctoken` (`calendarid`,`calendartype`,`synctoken`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarchanges`
--

LOCK TABLES `oc_calendarchanges` WRITE;
/*!40000 ALTER TABLE `oc_calendarchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects`
--

DROP TABLE IF EXISTS `oc_calendarobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarobjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `calendarid` bigint unsigned NOT NULL,
  `lastmodified` int unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `componenttype` varchar(8) COLLATE utf8mb4_bin DEFAULT NULL,
  `firstoccurence` bigint unsigned DEFAULT NULL,
  `lastoccurence` bigint unsigned DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `classification` int DEFAULT '0',
  `calendartype` int NOT NULL DEFAULT '0',
  `deleted_at` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calobjects_index` (`calendarid`,`calendartype`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects`
--

LOCK TABLES `oc_calendarobjects` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects_props`
--

DROP TABLE IF EXISTS `oc_calendarobjects_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarobjects_props` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `calendarid` bigint NOT NULL DEFAULT '0',
  `objectid` bigint unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `parameter` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `calendartype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `calendarobject_index` (`objectid`,`calendartype`),
  KEY `calendarobject_name_index` (`name`,`calendartype`),
  KEY `calendarobject_value_index` (`value`,`calendartype`),
  KEY `calendarobject_calid_index` (`calendarid`,`calendartype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects_props`
--

LOCK TABLES `oc_calendarobjects_props` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects_props` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects_props` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendars`
--

DROP TABLE IF EXISTS `oc_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendars` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `synctoken` int unsigned NOT NULL DEFAULT '1',
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `calendarorder` int unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `timezone` longtext COLLATE utf8mb4_bin,
  `components` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `transparent` smallint NOT NULL DEFAULT '0',
  `deleted_at` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calendars_index` (`principaluri`,`uri`),
  KEY `cals_princ_del_idx` (`principaluri`,`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendars`
--

LOCK TABLES `oc_calendars` WRITE;
/*!40000 ALTER TABLE `oc_calendars` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarsubscriptions`
--

DROP TABLE IF EXISTS `oc_calendarsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarsubscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `principaluri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `displayname` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `refreshrate` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `calendarorder` int unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `striptodos` smallint DEFAULT NULL,
  `stripalarms` smallint DEFAULT NULL,
  `stripattachments` smallint DEFAULT NULL,
  `lastmodified` int unsigned DEFAULT NULL,
  `synctoken` int unsigned NOT NULL DEFAULT '1',
  `source` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calsub_index` (`principaluri`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarsubscriptions`
--

LOCK TABLES `oc_calendarsubscriptions` WRITE;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards`
--

DROP TABLE IF EXISTS `oc_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_cards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint NOT NULL DEFAULT '0',
  `carddata` longblob,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `lastmodified` bigint unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `uid` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cards_abid` (`addressbookid`),
  KEY `cards_abiduri` (`addressbookid`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards`
--

LOCK TABLES `oc_cards` WRITE;
/*!40000 ALTER TABLE `oc_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards_properties`
--

DROP TABLE IF EXISTS `oc_cards_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_cards_properties` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint NOT NULL DEFAULT '0',
  `cardid` bigint unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `preferred` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `card_contactid_index` (`cardid`),
  KEY `card_name_index` (`name`),
  KEY `card_value_index` (`value`),
  KEY `cards_prop_abid` (`addressbookid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards_properties`
--

LOCK TABLES `oc_cards_properties` WRITE;
/*!40000 ALTER TABLE `oc_cards_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_cards_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_circle`
--

DROP TABLE IF EXISTS `oc_circles_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_circle` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(127) COLLATE utf8mb4_bin NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  `sanitized_name` varchar(127) COLLATE utf8mb4_bin DEFAULT '',
  `instance` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  `config` int unsigned DEFAULT NULL,
  `source` int unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8mb4_bin,
  `description` longtext COLLATE utf8mb4_bin,
  `creation` datetime DEFAULT NULL,
  `contact_addressbook` int unsigned DEFAULT NULL,
  `contact_groupname` varchar(127) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8195F548E3C68343` (`unique_id`),
  KEY `IDX_8195F548D48A2F7C` (`config`),
  KEY `IDX_8195F5484230B1DE` (`instance`),
  KEY `IDX_8195F5485F8A7F73` (`source`),
  KEY `IDX_8195F548C317B362` (`sanitized_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_circle`
--

LOCK TABLES `oc_circles_circle` WRITE;
/*!40000 ALTER TABLE `oc_circles_circle` DISABLE KEYS */;
INSERT INTO `oc_circles_circle` VALUES (1,'dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','user:atlas:dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','atlas','','',1,1,'[]','','2022-10-14 16:48:43',0,''),(2,'iIeR3am48VZU6rhM86uBaQi55acnM5b','app:circles:iIeR3am48VZU6rhM86uBaQi55acnM5b','Circles','','',8193,10001,'[]','','2022-10-14 16:48:43',0,'');
/*!40000 ALTER TABLE `oc_circles_circle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_event`
--

DROP TABLE IF EXISTS `oc_circles_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_event` (
  `token` varchar(63) COLLATE utf8mb4_bin NOT NULL,
  `instance` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `event` longtext COLLATE utf8mb4_bin,
  `result` longtext COLLATE utf8mb4_bin,
  `interface` int NOT NULL DEFAULT '0',
  `severity` int DEFAULT NULL,
  `retry` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `creation` bigint DEFAULT NULL,
  PRIMARY KEY (`token`,`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_event`
--

LOCK TABLES `oc_circles_event` WRITE;
/*!40000 ALTER TABLE `oc_circles_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_member`
--

DROP TABLE IF EXISTS `oc_circles_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_member` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `single_id` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `circle_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `member_id` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` varchar(127) COLLATE utf8mb4_bin NOT NULL,
  `user_type` smallint NOT NULL DEFAULT '1',
  `instance` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  `invited_by` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `level` smallint NOT NULL,
  `status` varchar(15) COLLATE utf8mb4_bin DEFAULT NULL,
  `note` longtext COLLATE utf8mb4_bin,
  `cached_name` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  `cached_update` datetime DEFAULT NULL,
  `contact_id` varchar(127) COLLATE utf8mb4_bin DEFAULT NULL,
  `contact_meta` longtext COLLATE utf8mb4_bin,
  `joined` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `circles_member_cisiuiutil` (`circle_id`,`single_id`,`user_id`,`user_type`,`instance`,`level`),
  KEY `circles_member_cisi` (`circle_id`,`single_id`),
  KEY `IDX_25C66A49E7A1254A` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_member`
--

LOCK TABLES `oc_circles_member` WRITE;
/*!40000 ALTER TABLE `oc_circles_member` DISABLE KEYS */;
INSERT INTO `oc_circles_member` VALUES (1,'iIeR3am48VZU6rhM86uBaQi55acnM5b','iIeR3am48VZU6rhM86uBaQi55acnM5b','iIeR3am48VZU6rhM86uBaQi55acnM5b','circles',10000,'',NULL,9,'Member','[]','Circles','2022-10-14 16:48:43','',NULL,'2022-10-14 16:48:43'),(2,'dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','atlas',1,'','iIeR3am48VZU6rhM86uBaQi55acnM5b',9,'Member','[]','atlas','2022-10-14 16:48:43','',NULL,'2022-10-14 16:48:43');
/*!40000 ALTER TABLE `oc_circles_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_membership`
--

DROP TABLE IF EXISTS `oc_circles_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_membership` (
  `circle_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `single_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `level` int unsigned NOT NULL,
  `inheritance_first` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `inheritance_last` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `inheritance_depth` int unsigned NOT NULL,
  `inheritance_path` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`single_id`,`circle_id`),
  KEY `IDX_8FC816EAE7C1D92B` (`single_id`),
  KEY `circles_membership_ifilci` (`inheritance_first`,`inheritance_last`,`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_membership`
--

LOCK TABLES `oc_circles_membership` WRITE;
/*!40000 ALTER TABLE `oc_circles_membership` DISABLE KEYS */;
INSERT INTO `oc_circles_membership` VALUES ('dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz',9,'dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz','dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz',1,'[\"dBaGgYJpl1lmqS5ZAGv5e1Z7AIrlHaz\"]'),('iIeR3am48VZU6rhM86uBaQi55acnM5b','iIeR3am48VZU6rhM86uBaQi55acnM5b',9,'iIeR3am48VZU6rhM86uBaQi55acnM5b','iIeR3am48VZU6rhM86uBaQi55acnM5b',1,'[\"iIeR3am48VZU6rhM86uBaQi55acnM5b\"]');
/*!40000 ALTER TABLE `oc_circles_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_mount`
--

DROP TABLE IF EXISTS `oc_circles_mount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_mount` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `mount_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `circle_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `single_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `parent` int DEFAULT NULL,
  `mountpoint` longtext COLLATE utf8mb4_bin,
  `mountpoint_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `circles_mount_cimipt` (`circle_id`,`mount_id`,`parent`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_mount`
--

LOCK TABLES `oc_circles_mount` WRITE;
/*!40000 ALTER TABLE `oc_circles_mount` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_mount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_mountpoint`
--

DROP TABLE IF EXISTS `oc_circles_mountpoint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_mountpoint` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `mount_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `single_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `mountpoint` longtext COLLATE utf8mb4_bin,
  `mountpoint_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `circles_mountpoint_ms` (`mount_id`,`single_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_mountpoint`
--

LOCK TABLES `oc_circles_mountpoint` WRITE;
/*!40000 ALTER TABLE `oc_circles_mountpoint` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_mountpoint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_remote`
--

DROP TABLE IF EXISTS `oc_circles_remote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_remote` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) COLLATE utf8mb4_bin NOT NULL DEFAULT 'Unknown',
  `interface` int NOT NULL DEFAULT '0',
  `uid` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `instance` varchar(127) COLLATE utf8mb4_bin DEFAULT NULL,
  `href` varchar(254) COLLATE utf8mb4_bin DEFAULT NULL,
  `item` longtext COLLATE utf8mb4_bin,
  `creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F94EF834230B1DE` (`instance`),
  KEY `IDX_F94EF83539B0606` (`uid`),
  KEY `IDX_F94EF8334F8E741` (`href`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_remote`
--

LOCK TABLES `oc_circles_remote` WRITE;
/*!40000 ALTER TABLE `oc_circles_remote` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_remote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_share_lock`
--

DROP TABLE IF EXISTS `oc_circles_share_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_share_lock` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `circle_id` varchar(31) COLLATE utf8mb4_bin NOT NULL,
  `instance` varchar(127) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_337F52F8126F525E70EE2FF6` (`item_id`,`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_share_lock`
--

LOCK TABLES `oc_circles_share_lock` WRITE;
/*!40000 ALTER TABLE `oc_circles_share_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_share_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_token`
--

DROP TABLE IF EXISTS `oc_circles_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_token` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `share_id` int DEFAULT NULL,
  `circle_id` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `single_id` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `member_id` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `token` varchar(31) COLLATE utf8mb4_bin DEFAULT NULL,
  `password` varchar(127) COLLATE utf8mb4_bin DEFAULT NULL,
  `accepted` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sicisimit` (`share_id`,`circle_id`,`single_id`,`member_id`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_token`
--

LOCK TABLES `oc_circles_token` WRITE;
/*!40000 ALTER TABLE `oc_circles_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_accesscache`
--

DROP TABLE IF EXISTS `oc_collres_accesscache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_accesscache` (
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `collection_id` bigint NOT NULL DEFAULT '0',
  `resource_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `resource_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `access` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`,`collection_id`,`resource_type`,`resource_id`),
  KEY `collres_user_res` (`user_id`,`resource_type`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_accesscache`
--

LOCK TABLES `oc_collres_accesscache` WRITE;
/*!40000 ALTER TABLE `oc_collres_accesscache` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_accesscache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_collections`
--

DROP TABLE IF EXISTS `oc_collres_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_collections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_collections`
--

LOCK TABLES `oc_collres_collections` WRITE;
/*!40000 ALTER TABLE `oc_collres_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_resources`
--

DROP TABLE IF EXISTS `oc_collres_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_resources` (
  `collection_id` bigint NOT NULL,
  `resource_type` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `resource_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`collection_id`,`resource_type`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_resources`
--

LOCK TABLES `oc_collres_resources` WRITE;
/*!40000 ALTER TABLE `oc_collres_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments`
--

DROP TABLE IF EXISTS `oc_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned NOT NULL DEFAULT '0',
  `topmost_parent_id` bigint unsigned NOT NULL DEFAULT '0',
  `children_count` int unsigned NOT NULL DEFAULT '0',
  `actor_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `actor_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `message` longtext COLLATE utf8mb4_bin,
  `verb` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `creation_timestamp` datetime DEFAULT NULL,
  `latest_child_timestamp` datetime DEFAULT NULL,
  `object_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `reference_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `reactions` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_parent_id_index` (`parent_id`),
  KEY `comments_topmost_parent_id_idx` (`topmost_parent_id`),
  KEY `comments_object_index` (`object_type`,`object_id`,`creation_timestamp`),
  KEY `comments_actor_index` (`actor_type`,`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments`
--

LOCK TABLES `oc_comments` WRITE;
/*!40000 ALTER TABLE `oc_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments_read_markers`
--

DROP TABLE IF EXISTS `oc_comments_read_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_comments_read_markers` (
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `object_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `marker_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`object_type`,`object_id`),
  KEY `comments_marker_object_index` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments_read_markers`
--

LOCK TABLES `oc_comments_read_markers` WRITE;
/*!40000 ALTER TABLE `oc_comments_read_markers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments_read_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_cal_proxy`
--

DROP TABLE IF EXISTS `oc_dav_cal_proxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_dav_cal_proxy` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `proxy_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `permissions` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_cal_proxy_uidx` (`owner_id`,`proxy_id`,`permissions`),
  KEY `dav_cal_proxy_ipid` (`proxy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_cal_proxy`
--

LOCK TABLES `oc_dav_cal_proxy` WRITE;
/*!40000 ALTER TABLE `oc_dav_cal_proxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_cal_proxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_shares`
--

DROP TABLE IF EXISTS `oc_dav_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_dav_shares` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `access` smallint DEFAULT NULL,
  `resourceid` bigint unsigned NOT NULL,
  `publicuri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_shares_index` (`principaluri`,`resourceid`,`type`,`publicuri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_shares`
--

LOCK TABLES `oc_dav_shares` WRITE;
/*!40000 ALTER TABLE `oc_dav_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_direct_edit`
--

DROP TABLE IF EXISTS `oc_direct_edit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_direct_edit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `editor_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `file_id` bigint NOT NULL,
  `user_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `share_id` bigint DEFAULT NULL,
  `timestamp` bigint unsigned NOT NULL,
  `accessed` tinyint(1) DEFAULT '0',
  `file_path` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4D5AFECA5F37A13B` (`token`),
  KEY `direct_edit_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_direct_edit`
--

LOCK TABLES `oc_direct_edit` WRITE;
/*!40000 ALTER TABLE `oc_direct_edit` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_direct_edit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_directlink`
--

DROP TABLE IF EXISTS `oc_directlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_directlink` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `file_id` bigint unsigned NOT NULL,
  `token` varchar(60) COLLATE utf8mb4_bin DEFAULT NULL,
  `expiration` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `directlink_token_idx` (`token`),
  KEY `directlink_expiration_idx` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_directlink`
--

LOCK TABLES `oc_directlink` WRITE;
/*!40000 ALTER TABLE `oc_directlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_directlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_federated_reshares`
--

DROP TABLE IF EXISTS `oc_federated_reshares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_federated_reshares` (
  `share_id` bigint NOT NULL,
  `remote_id` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_federated_reshares`
--

LOCK TABLES `oc_federated_reshares` WRITE;
/*!40000 ALTER TABLE `oc_federated_reshares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_federated_reshares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_file_locks`
--

DROP TABLE IF EXISTS `oc_file_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_file_locks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `lock` int NOT NULL DEFAULT '0',
  `key` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `ttl` int NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lock_key_index` (`key`),
  KEY `lock_ttl_index` (`ttl`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_file_locks`
--

LOCK TABLES `oc_file_locks` WRITE;
/*!40000 ALTER TABLE `oc_file_locks` DISABLE KEYS */;
INSERT INTO `oc_file_locks` VALUES (1,0,'files/fc97be473c6757cff2a079334d67b111',1665769751),(3,0,'files/206637cb9a24a6239e58ab99e2ea2d94',1665769751),(4,0,'files/aeef37024c32696a315bd1a860601f28',1665769752),(5,0,'files/f72c10029468cc6446743032f5635537',1665769752),(6,0,'files/ded44ca7aceb7d7e49cb6f7c17938735',1665769752),(7,0,'files/97deff70e207c884c4e32a151fbe1c54',1665769752),(8,0,'files/799ed22250977bcc8546fa1aed9736a6',1665769752),(9,0,'files/72d9deb681ad1268ec1011d17fa33217',1665769752),(10,0,'files/6b8ae4a0a76328be6bcbe3b61bb84dfc',1665769752),(11,0,'files/0ae190fb2455ff4c8a8891ab873a5f9b',1665769752),(12,0,'files/76bda8cede95a7b7856fc77ca37778c5',1665769752),(13,0,'files/6c4b03c23f5c3d769cb6ece7236ab782',1665769752),(14,0,'files/04140ab97e6965e2c41be78b3b599612',1665769752),(15,0,'files/d8ada16a9a94791be1af9edd0a40d89a',1665769752),(16,0,'files/c4f9517a4bbd388f498026492ebb58f0',1665769752),(17,0,'files/625bb0b2766bfc94275dccdfa18cc01a',1665769752),(18,0,'files/dbc7dc159187a7b767f49e4f6016f1aa',1665769752),(19,0,'files/8748fa60cb75714ba830b2aab11a5635',1665769752),(20,0,'files/cbdc4c07c85c9ebe85f7d368143c9717',1665769752),(21,0,'files/85d67f7d3a2215c8ffd05a6b4a84c770',1665769752),(22,0,'files/745ebe51ce313af68f89e6c900ef0246',1665769752),(23,0,'files/2be21aeed6c3b76f8bca27b16a30b97e',1665769752),(24,0,'files/859f1c5e0b596b6396066d1114f1813d',1665769753),(25,0,'files/cc8533df33f62e9be597b934096899ab',1665769753),(26,0,'files/b257b3647fe789931d81d4fb71d793a3',1665769753),(27,0,'files/ff2b430ba715efcb499c73c3a847a291',1665769753),(28,0,'files/0e0523d906bab5a3010e70d711444086',1665769753),(29,0,'files/6e4f92595c9c5dc7c5203b1168b63793',1665769753),(30,0,'files/941faf9718fae5aa68d3fe1e9f2bfac0',1665769756),(31,0,'files/783b072eb01ca08bab77d51f6ef44008',1665769756),(32,0,'files/38d3fc13a505a341da34815c5ccc8b3d',1665769756),(34,0,'files/c6fa1fff8e4b03f9da01dc08312bc141',1665769756),(35,0,'files/6794bf9307f3f099d814d6733f5d486a',1665769757);
/*!40000 ALTER TABLE `oc_file_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_file_metadata`
--

DROP TABLE IF EXISTS `oc_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_file_metadata` (
  `id` int NOT NULL,
  `group_name` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `metadata` json NOT NULL,
  PRIMARY KEY (`id`,`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_file_metadata`
--

LOCK TABLES `oc_file_metadata` WRITE;
/*!40000 ALTER TABLE `oc_file_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache`
--

DROP TABLE IF EXISTS `oc_filecache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_filecache` (
  `fileid` bigint NOT NULL AUTO_INCREMENT,
  `storage` bigint NOT NULL DEFAULT '0',
  `path` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  `path_hash` varchar(32) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `parent` bigint NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8mb4_bin DEFAULT NULL,
  `mimetype` bigint NOT NULL DEFAULT '0',
  `mimepart` bigint NOT NULL DEFAULT '0',
  `size` bigint NOT NULL DEFAULT '0',
  `mtime` bigint NOT NULL DEFAULT '0',
  `storage_mtime` bigint NOT NULL DEFAULT '0',
  `encrypted` int NOT NULL DEFAULT '0',
  `unencrypted_size` bigint NOT NULL DEFAULT '0',
  `etag` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `permissions` int DEFAULT '0',
  `checksum` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`fileid`),
  UNIQUE KEY `fs_storage_path_hash` (`storage`,`path_hash`),
  KEY `fs_parent_name_hash` (`parent`,`name`),
  KEY `fs_storage_mimetype` (`storage`,`mimetype`),
  KEY `fs_storage_mimepart` (`storage`,`mimepart`),
  KEY `fs_storage_size` (`storage`,`size`,`fileid`),
  KEY `fs_id_storage_size` (`fileid`,`storage`,`size`),
  KEY `fs_mtime` (`mtime`),
  KEY `fs_size` (`size`),
  KEY `fs_storage_path_prefix` (`storage`,`path`(64))
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache`
--

LOCK TABLES `oc_filecache` WRITE;
/*!40000 ALTER TABLE `oc_filecache` DISABLE KEYS */;
INSERT INTO `oc_filecache` VALUES (1,1,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,-1,1665766021,1665766021,0,0,'63499285b17a5',23,''),(2,1,'appdata_occlus6dapmo','e6b40f21c52484ed5b93728d0f41314a',1,'appdata_occlus6dapmo',2,1,0,1665766151,1665766151,0,0,'63499285b0f2f',31,''),(3,1,'appdata_occlus6dapmo/appstore','01d9fcb1f1da05c614883c36b52b5eab',2,'appstore',2,1,0,1665766029,1665766029,0,0,'63499288623a3',31,''),(4,1,'appdata_occlus6dapmo/appstore/apps.json','aecce56d990d186871cb461c0d57e7e8',3,'apps.json',4,3,2165028,1665766029,1665766029,0,0,'10331986583bdf9bfb1f7f1f7b9c7d14',27,''),(5,2,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,24049432,1529666681,1529666681,0,0,'5b2cdc7a06683',23,''),(6,2,'files','45b963397aa40d4a0063e0d85e4fe7a1',5,'files',2,1,24049432,1665766062,1665766062,0,0,'634992af0a310',31,''),(7,2,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',6,'Documents',2,1,399534,1665766047,1665766047,0,0,'6349929fa9fb6',31,''),(8,2,'files/Documents/Example.md','efe0853470dd0663db34818b444328dd',7,'Example.md',6,5,1095,1665766046,1665766046,0,0,'ff4da4eb4715520ab29ea1cbc5b585b2',27,''),(9,2,'files/Documents/Nextcloud flyer.pdf','9c5b4dc7182a7435767708ac3e8d126c',7,'Nextcloud flyer.pdf',7,3,374008,1665766047,1665766047,0,0,'3b2cd633fd5789712e0f89952513383e',27,''),(10,2,'files/Documents/Readme.md','51ec9e44357d147dd5c212b850f6910f',7,'Readme.md',6,5,136,1665766047,1665766047,0,0,'51a9ddcf1cc105392c054140d0d8c99c',27,''),(11,2,'files/Documents/Welcome to Nextcloud Hub.docx','b44cb84f22ceddc4ca2826e026038091',7,'Welcome to Nextcloud Hub.docx',8,3,24295,1665766047,1665766047,0,0,'70cd820a6339fdacc7e866eab7b78457',27,''),(12,2,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',6,'Photos',2,1,5656463,1665766050,1665766050,0,0,'634992a34841d',31,''),(13,2,'files/Photos/Birdie.jpg','cd31c7af3a0ec6e15782b5edd2774549',12,'Birdie.jpg',10,9,593508,1665766048,1665766048,0,0,'697b9797b1acb48a030d59f8edcb6377',27,''),(14,2,'files/Photos/Frog.jpg','d6219add1a9129ed0c1513af985e2081',12,'Frog.jpg',10,9,457744,1665766049,1665766049,0,0,'3d46d6c36fc9ad86807fdaf4eb517126',27,''),(15,2,'files/Photos/Gorilla.jpg','6d5f5956d8ff76a5f290cebb56402789',12,'Gorilla.jpg',10,9,474653,1665766049,1665766049,0,0,'5544dee69edbcef57ec82db393a5edd1',27,''),(16,2,'files/Photos/Library.jpg','0b785d02a19fc00979f82f6b54a05805',12,'Library.jpg',10,9,2170375,1665766049,1665766049,0,0,'d8f1ffbca813e01db3f0c2b241ff6ab8',27,''),(17,2,'files/Photos/Nextcloud community.jpg','b9b3caef83a2a1c20354b98df6bcd9d0',12,'Nextcloud community.jpg',10,9,797325,1665766050,1665766050,0,0,'48ffa1a786a8571b797616529c768fc3',27,''),(18,2,'files/Photos/Readme.md','2a4ac36bb841d25d06d164f291ee97db',12,'Readme.md',6,5,150,1665766050,1665766050,0,0,'80b77a5693cdd98ffc9a61c6809cd106',27,''),(19,2,'files/Photos/Steps.jpg','7b2ca8d05bbad97e00cbf5833d43e912',12,'Steps.jpg',10,9,567689,1665766050,1665766050,0,0,'e7647c0c72aa89e7aa1665d82347aeae',27,''),(20,2,'files/Photos/Toucan.jpg','681d1e78f46a233e12ecfa722cbc2aef',12,'Toucan.jpg',10,9,167989,1665766050,1665766050,0,0,'5978862bd7b35e4d8fa359a051c17271',27,''),(21,2,'files/Photos/Vineyard.jpg','14e5f2670b0817614acd52269d971db8',12,'Vineyard.jpg',10,9,427030,1665766051,1665766051,0,0,'9e71ebc5b8b4f86a3ebf4789f3bb8a12',27,''),(22,2,'files/Шаблоны','32743fc4196709e150544bcf7d35be54',6,'Шаблоны',2,1,238269,1665766057,1665766057,0,0,'634992a994b8e',31,''),(23,2,'files/Шаблоны/Business model canvas.odg','d2928c01e2a2a596bad63f3ce330340d',22,'Business model canvas.odg',11,3,16988,1665766052,1665766052,0,0,'8fef8caf3567fb7b7360f38d7f2477ee',27,''),(24,2,'files/Шаблоны/Diagram & table.ods','ab7b65f2ffbaa387dff2a22166fcc422',22,'Diagram & table.ods',12,3,13378,1665766052,1665766052,0,0,'b988590ee78017a305bdb69d45c315e3',27,''),(25,2,'files/Шаблоны/Elegant.odp','84e4d694b123ac2dd753daa10efb6ada',22,'Elegant.odp',13,3,14316,1665766053,1665766053,0,0,'8747751ca1963655f8fc0ae38403a626',27,''),(26,2,'files/Шаблоны/Expense report.ods','81b3ac7c38dfc3c390e572de0f42e7f0',22,'Expense report.ods',12,3,13441,1665766053,1665766053,0,0,'9965aa03093709c95326a93aa812d838',27,''),(27,2,'files/Шаблоны/Flowchart.odg','a67f73a8abbe3e69569dc0459aafa8fc',22,'Flowchart.odg',11,3,11836,1665766053,1665766053,0,0,'ede8ced05c08052efb4bc833319d27f5',27,''),(28,2,'files/Шаблоны/Impact effort matrix.whiteboard','48f78fc60be0a64440c44a3fdc2e1d92',22,'Impact effort matrix.whiteboard',14,3,52674,1665766054,1665766054,0,0,'492dd2ebd6ab62894a3152a9bfbf0d44',27,''),(29,2,'files/Шаблоны/Invoice.odt','4a60df9d144a0b680a3ef6bd6140ec9d',22,'Invoice.odt',15,3,17276,1665766054,1665766054,0,0,'e68c64333aed19cb3a3d29e3cf1217e8',27,''),(30,2,'files/Шаблоны/Letter.odt','41a85da1c31ae56a0e7528de96ac3779',22,'Letter.odt',15,3,15961,1665766055,1665766055,0,0,'ac18d2e150d99713e407a1d1b43e4c36',27,''),(31,2,'files/Шаблоны/Meeting notes.md','5f2853c91c82ee8cac05eca924947a6e',22,'Meeting notes.md',6,5,326,1665766055,1665766055,0,0,'a83c55c530b33785e37b9d8ece982aa0',27,''),(32,2,'files/Шаблоны/Mindmap.odg','e80d4d1f8653ed3c5b9331936097ab33',22,'Mindmap.odg',11,3,13653,1665766055,1665766055,0,0,'ab30db5770aeaa67df9ac2dc15b47912',27,''),(33,2,'files/Шаблоны/Org chart.odg','c972c2f87b49757b7f7cc824b8b58500',22,'Org chart.odg',11,3,13878,1665766055,1665766055,0,0,'28b96bfbeba9f7accc82143928c4e808',27,''),(34,2,'files/Шаблоны/Product plan.md','a9763dd69fe6a70172c67cf932462e2c',22,'Product plan.md',6,5,573,1665766056,1665766056,0,0,'3a5c4ad25bfd7d94e27473b913b4852f',27,''),(35,2,'files/Шаблоны/Readme.md','86f8b32fa5a3b87df88515298a8daf92',22,'Readme.md',6,5,554,1665766056,1665766056,0,0,'619c7ae7dffe3f7f7254a342d1bc1ca6',27,''),(36,2,'files/Шаблоны/SWOT analysis.whiteboard','e9b428ce26f8dcdc377c17ca0b1f3503',22,'SWOT analysis.whiteboard',14,3,38605,1665766057,1665766057,0,0,'a3f04073203f743b68b78a51a81ea727',27,''),(37,2,'files/Шаблоны/Simple.odp','b3ded56369aeae536966c6b51faf0007',22,'Simple.odp',13,3,14810,1665766057,1665766057,0,0,'6cc8e9f2674a90c13bc4711c11b6bf5e',27,''),(38,2,'files/Nextcloud Manual.pdf','2bc58a43566a8edde804a4a97a9c7469',6,'Nextcloud Manual.pdf',7,3,12764907,1665766058,1665766058,0,0,'34d654c6ef1c0172431fddba9373ca6a',27,''),(39,2,'files/Nextcloud intro.mp4','e4919345bcc87d4585a5525daaad99c0',6,'Nextcloud intro.mp4',17,16,3963036,1665766059,1665766059,0,0,'d43470610661bd4cbef342780da0c6fa',27,''),(40,2,'files/Nextcloud.png','2bcc0ff06465ef1bfc4a868efde1e485',6,'Nextcloud.png',18,9,50598,1665766060,1665766060,0,0,'4ac018868c88df46fd62284cacf18558',27,''),(41,2,'files/Reasons to use Nextcloud.pdf','418b19142a61c5bef296ea56ee144ca3',6,'Reasons to use Nextcloud.pdf',7,3,976625,1665766060,1665766060,0,0,'4711585bfed9dc1cebad65b8ca1059f4',27,''),(42,1,'appdata_occlus6dapmo/js','22b2d9344d20c1ae3c526e7b43720ce0',2,'js',2,1,0,1666028860,1666028860,0,0,'634992ec243a9',31,''),(43,1,'appdata_occlus6dapmo/js/core','f6de8f231804757c03dd593f61c9dad1',42,'core',2,1,0,1665766124,1665766124,0,0,'634992ec632c3',31,''),(44,1,'appdata_occlus6dapmo/js/core/merged-template-prepend.js','b001b7d8f018b746cac1e3f7675cadeb',43,'merged-template-prepend.js',19,3,11942,1665766124,1665766124,0,0,'e63eca0d0dadb7864addadfe997296d4',27,''),(45,1,'appdata_occlus6dapmo/js/core/merged-template-prepend.js.deps','fd5bf425df54485ee2ae2ccbdbd35926',43,'merged-template-prepend.js.deps',14,3,246,1665766124,1665766124,0,0,'1b5b6678bce2c4c820138dbcbee723c6',27,''),(46,1,'appdata_occlus6dapmo/js/core/merged-template-prepend.js.gzip','e9c5884356b442d7278a45853f7d6a82',43,'merged-template-prepend.js.gzip',20,3,3054,1665766124,1665766124,0,0,'6c200446744a3a59e34c163d82c9d319',27,''),(47,1,'appdata_occlus6dapmo/css','6e026b00a5febc2e00d3037584bdc4dc',2,'css',2,1,0,1666028863,1666028863,0,0,'634992ed5cbcb',31,''),(48,1,'appdata_occlus6dapmo/css/icons','0d41b066ad20db17d8662ef07ce93c88',47,'icons',2,1,0,1665766128,1665766128,0,0,'634992eda42af',31,''),(49,1,'appdata_occlus6dapmo/css/core','300b672cc8ef8bd315f2831e5317cc30',47,'core',2,1,0,1529667070,1529667070,0,0,'634992ee39721',31,''),(50,1,'appdata_occlus6dapmo/css/icons/icons-vars.css','0afdc47b28431cc005445fd6ef421d96',48,'icons-vars.css',21,5,165213,1666028864,1666028864,0,0,'8356481bb4b335efea7a4911291e04ad',27,''),(51,1,'appdata_occlus6dapmo/css/icons/icons-list.template','4ef51cd11c10e2ac8f011d1f4b7f5e09',48,'icons-list.template',14,3,16516,1666028864,1666028864,0,0,'df17268b3753cc44459aee5e0becafe1',27,''),(52,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-server.css','7b74522399e537e2487d9f765a20c709',49,'7fcc-76aa-server.css',21,5,139049,1665766128,1665766128,0,0,'22d23df2fee5ebea0c37006d1261e2d6',27,''),(53,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-server.css.deps','7cab6ad2eb68ac1faf6d538453ef433b',49,'7fcc-76aa-server.css.deps',14,3,759,1665766129,1665766129,0,0,'a02f2986fcbc973939e4127699077db1',27,''),(54,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-server.css.gzip','60582339439d8faad721d66feaa58bcb',49,'7fcc-76aa-server.css.gzip',20,3,19855,1665766129,1665766129,0,0,'d1d046e1a5faa955bb413a33987e15d5',27,''),(55,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-css-variables.css','fe4e2692b43f0d32b3647a5f9a78df8d',49,'7fcc-76aa-css-variables.css',21,5,1820,1665766129,1665766129,0,0,'729746edb8fed5e549bb13bc9bf02b62',27,''),(56,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-css-variables.css.deps','e9b9c5a8a284a6bc146c420d3ffc8168',49,'7fcc-76aa-css-variables.css.deps',14,3,176,1665766130,1665766130,0,0,'c52d681c016dc63e6b8e6412979d18dd',27,''),(57,1,'appdata_occlus6dapmo/css/core/7fcc-76aa-css-variables.css.gzip','99b632a5ad0e272273261acc942ec423',49,'7fcc-76aa-css-variables.css.gzip',20,3,692,1665766130,1665766130,0,0,'6aab712472c63487e7622a1dcdadd379',27,''),(58,1,'appdata_occlus6dapmo/css/theming','c278817159d48ba9b3bfe33470d84f49',47,'theming',2,1,0,1529667044,1529667044,0,0,'634992f391081',31,''),(59,1,'appdata_occlus6dapmo/css/theming/d71e-76aa-theming.css','a419f070e7cdb205e1d574b488dc3b7b',58,'d71e-76aa-theming.css',21,5,1764,1665766132,1665766132,0,0,'7ca4e0cc4d9b48b3acd333dac83bd03d',27,''),(60,1,'appdata_occlus6dapmo/css/theming/d71e-76aa-theming.css.deps','50fceec60c8c4a228b872f764199a414',58,'d71e-76aa-theming.css.deps',14,3,179,1665766132,1665766132,0,0,'11ee51d5b577119e48f36ea3235dade9',27,''),(61,1,'appdata_occlus6dapmo/css/theming/d71e-76aa-theming.css.gzip','7e34ef01903046a6a4d06b5614e62dab',58,'d71e-76aa-theming.css.gzip',20,3,527,1665766132,1665766132,0,0,'44b08504bf0b0f604ea0509924a2c5c1',27,''),(62,1,'appdata_occlus6dapmo/css/dashboard','dda9810a5fcff04ecca5629c19ac31fa',47,'dashboard',2,1,0,1529667070,1529667070,0,0,'634992fb58ec0',31,''),(63,1,'appdata_occlus6dapmo/css/dashboard/1c83-76aa-dashboard.css','3005b5e6fb7e8f3d8e3727f7b648c2e1',62,'1c83-76aa-dashboard.css',21,5,2050,1665766140,1665766140,0,0,'bba837950a4bb8b162a4ab2fc34e0b03',27,''),(64,1,'appdata_occlus6dapmo/css/dashboard/1c83-76aa-dashboard.css.deps','2cb28b3d5d5920b9b4e17049bc046b20',62,'1c83-76aa-dashboard.css.deps',14,3,183,1665766141,1665766141,0,0,'bdd67fe034b3a4d3d7a15d284a354b1b',27,''),(65,1,'appdata_occlus6dapmo/css/dashboard/1c83-76aa-dashboard.css.gzip','7ec56c22d220f44c4f9c1ceeeb641b8d',62,'1c83-76aa-dashboard.css.gzip',20,3,594,1665766141,1665766141,0,0,'8a32265fc5d35eea4cbbc238cfe20f4f',27,''),(66,1,'appdata_occlus6dapmo/css/activity','51013785aa9c42b50a6e6175a2d394ab',47,'activity',2,1,0,1529667071,1529667071,0,0,'634992fd637df',31,''),(67,1,'appdata_occlus6dapmo/css/activity/6e52-76aa-style.css','db79e237a18b845d2ef29afd8a69ec67',66,'6e52-76aa-style.css',21,5,3353,1665766142,1665766142,0,0,'a87ebf13296cc22ef32f193e88f2f914',27,''),(68,1,'appdata_occlus6dapmo/css/activity/6e52-76aa-style.css.deps','9f9d1e9ec372f04473140d9bd9dd7407',66,'6e52-76aa-style.css.deps',14,3,178,1665766142,1665766142,0,0,'578a5dde53250a3a9a4baf53f465b0bf',27,''),(69,1,'appdata_occlus6dapmo/css/activity/6e52-76aa-style.css.gzip','b199166e7c927148581b04504c2a6676',66,'6e52-76aa-style.css.gzip',20,3,1108,1665766142,1665766142,0,0,'28287aabdad7c3b9ba871d8ff5ea0298',27,''),(70,1,'appdata_occlus6dapmo/css/text','1d4c19bc9bf579d5d31524e75711833f',47,'text',2,1,0,1529667072,1529667072,0,0,'634992fe94cb4',31,''),(71,1,'appdata_occlus6dapmo/css/text/8931-76aa-icons.css','1ec55fae24527bf7e77c2a67b189fadd',70,'8931-76aa-icons.css',21,5,5861,1665766143,1665766143,0,0,'335fe6bb1244c671e627da845e8ac089',27,''),(72,1,'appdata_occlus6dapmo/css/text/8931-76aa-icons.css.deps','452d8304b2c02a239e39016616823016',70,'8931-76aa-icons.css.deps',14,3,174,1665766143,1665766143,0,0,'a6a65ca1a392f89010998edd2e8c1dec',27,''),(73,1,'appdata_occlus6dapmo/css/text/8931-76aa-icons.css.gzip','adb6e113a81a2988c4568f0693f3b121',70,'8931-76aa-icons.css.gzip',20,3,832,1665766144,1665766144,0,0,'a42cfa1f24660fb887de4f58e77aafeb',27,''),(74,1,'appdata_occlus6dapmo/css/notifications','a3ea266427a2c34e8251a772a07f791c',47,'notifications',2,1,0,1529667073,1529667073,0,0,'63499300453b2',31,''),(75,1,'appdata_occlus6dapmo/css/notifications/ae3e-76aa-styles.css','5980dd19fccffe3b3f175fc49a8e68fe',74,'ae3e-76aa-styles.css',21,5,5377,1665766145,1665766145,0,0,'dc3304737d57fd6c18b4a05017f07b52',27,''),(76,1,'appdata_occlus6dapmo/css/notifications/ae3e-76aa-styles.css.deps','a4d936b7d0d155a164b4e72ae13e59d7',74,'ae3e-76aa-styles.css.deps',14,3,184,1665766145,1665766145,0,0,'51c770307fced57a734c8acd75e360b0',27,''),(77,1,'appdata_occlus6dapmo/css/notifications/ae3e-76aa-styles.css.gzip','ab77531784f21835f5a33ad4189f4bef',74,'ae3e-76aa-styles.css.gzip',20,3,1176,1665766145,1665766145,0,0,'10fab5d0ecd8cb92b9849a48cc12a94e',27,''),(78,1,'appdata_occlus6dapmo/css/user_status','98fd42dec5d716b49045f88052ff2e09',47,'user_status',2,1,0,1529667074,1529667074,0,0,'6349930169f5e',31,''),(79,1,'appdata_occlus6dapmo/css/user_status/1bf6-76aa-user-status-menu.css','c6f2afa63be46fa2c0a1151514450d65',78,'1bf6-76aa-user-status-menu.css',21,5,999,1665766146,1665766146,0,0,'fd70bd5858d0d36cb89048104a798fba',27,''),(80,1,'appdata_occlus6dapmo/css/user_status/1bf6-76aa-user-status-menu.css.deps','a523dddf545551bceddeba008babcff7',78,'1bf6-76aa-user-status-menu.css.deps',14,3,192,1665766146,1665766146,0,0,'1c2b7c6031b85f3c96cb4c1753a8e1a1',27,''),(81,1,'appdata_occlus6dapmo/css/user_status/1bf6-76aa-user-status-menu.css.gzip','3d10fd1ddeeffdf7206552c1ecad85af',78,'1bf6-76aa-user-status-menu.css.gzip',20,3,232,1665766146,1665766146,0,0,'ade4d3b55135e9b4052e54c29c441834',27,''),(82,1,'appdata_occlus6dapmo/avatar','890ce2372dca13269b74ca4603506fd3',2,'avatar',2,1,0,1665766149,1665766149,0,0,'63499304e55c5',31,''),(83,1,'appdata_occlus6dapmo/avatar/atlas','af4699e01d76d7e07c0e0c201836dbb5',82,'atlas',2,1,0,1665766153,1665766153,0,0,'634993054a6ec',31,''),(84,1,'appdata_occlus6dapmo/preview','8ccbf998692ae1709b901ec8038c00ac',2,'preview',2,1,-1,1665766152,1665766152,0,0,'6349930838bed',31,''),(85,1,'appdata_occlus6dapmo/theming','358e8c71e2a2f057f218370b97f2e150',2,'theming',2,1,-1,1665766152,1665766152,0,0,'634993086594d',31,''),(86,1,'appdata_occlus6dapmo/avatar/atlas/avatar.png','1e350aa3f3b35cb2adacc3a32a1b7b34',83,'avatar.png',18,9,15907,1665766152,1665766152,0,0,'9e2a3b694d6b3a78299eec9d03048ce8',27,''),(87,1,'appdata_occlus6dapmo/theming/0','ec1501dfdaa713e88162dea260900cc6',85,'0',2,1,0,1666028870,1666028870,0,0,'634993084d61b',31,''),(88,1,'appdata_occlus6dapmo/preview/e','d5b4d0d2afb039643d8307d5b146773e',84,'e',2,1,-1,1665766152,1665766152,0,0,'634993085d78c',31,''),(89,1,'appdata_occlus6dapmo/preview/d','0203a9d48ede8ac6d3719b86e44ee641',84,'d',2,1,-1,1665766152,1665766152,0,0,'634993085d84a',31,''),(90,1,'appdata_occlus6dapmo/avatar/atlas/generated','0016baaec95cf9701c9aff4b6faeea7c',83,'generated',14,3,0,1665766152,1665766152,0,0,'7d6f59522dafec8f5970970ee3d5277f',27,''),(91,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_application-pdf.svg','6fc85ae329b90df59c0804cc973bb975',87,'icon-core-filetypes_application-pdf.svg',22,9,1054,1665766152,1665766152,0,0,'eb6896d180b79c3d6d1aba50599babd0',27,''),(92,1,'appdata_occlus6dapmo/preview/e/3','d9199b73eafb5a255708a76e7019b26d',88,'3',2,1,-1,1665766152,1665766152,0,0,'634993091477d',31,''),(93,1,'appdata_occlus6dapmo/preview/d/6','3bdd569c33718c6124bcde83b1be198b',89,'6',2,1,-1,1665766152,1665766152,0,0,'634993093a7e8',31,''),(94,1,'appdata_occlus6dapmo/avatar/atlas/avatar.64.png','5489a6e6441bcbbb51b01837db346731',83,'avatar.64.png',18,9,832,1665766153,1665766153,0,0,'c4efae6c6823f70ba4014a6c4d3954bb',27,''),(95,1,'appdata_occlus6dapmo/preview/e/3/6','899920470125c0a3ed56472cbc136329',92,'6',2,1,-1,1665766152,1665766152,0,0,'63499308dfc44',31,''),(96,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_video.svg','2093b6e411828c8ac1576367b26bd93b',87,'icon-core-filetypes_video.svg',22,9,277,1665766153,1665766153,0,0,'9b20a4027821edba5d29938cf7311d19',27,''),(97,1,'appdata_occlus6dapmo/preview/d/6/4','e4cdf2627603810a4b95b1722749ec8d',93,'4',2,1,-1,1665766152,1665766152,0,0,'6349930914671',31,''),(98,1,'appdata_occlus6dapmo/preview/e/3/6/9','3f61824b708d34d65c38a6d24956ecff',95,'9',2,1,-1,1665766152,1665766152,0,0,'63499308b910f',31,''),(99,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_x-office-presentation.svg','98b263c1cfc20ab3b90af7c86b4b6b65',87,'icon-core-filetypes_x-office-presentation.svg',22,9,261,1665766153,1665766153,0,0,'4fad9b343b335ae8e2cf8aa10a1f2c4d',27,''),(100,1,'appdata_occlus6dapmo/preview/d/6/4/5','a5cfe5e5a917be4766dda631b158795a',97,'5',2,1,-1,1665766152,1665766152,0,0,'63499308dfc0d',31,''),(101,1,'appdata_occlus6dapmo/preview/e/3/6/9/8','223567b2518cbdefc32f16d0d6612917',98,'8',2,1,-1,1665766152,1665766152,0,0,'634993088636e',31,''),(102,1,'appdata_occlus6dapmo/preview/e/3/6/9/8/5','23ec6929f1c5a5405157951a1ab60655',101,'5',2,1,-1,1665766152,1665766152,0,0,'6349930865911',31,''),(103,1,'appdata_occlus6dapmo/preview/d/6/4/5/9','257730e88bdba248ca2986bf6c0c79a9',100,'9',2,1,-1,1665766152,1665766152,0,0,'63499308b929d',31,''),(104,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_file.svg','f4718b23988de350e7fbe52bd506ab59',87,'icon-core-filetypes_file.svg',22,9,228,1665766153,1665766153,0,0,'5ccb9cb6d13c0e9811c04064db9b6977',27,''),(105,1,'appdata_occlus6dapmo/preview/d/6/4/5/9/2','4b1c8a9d90894a91b77d69ad4ac4c840',103,'2',2,1,-1,1665766152,1665766152,0,0,'634993088c498',31,''),(106,1,'appdata_occlus6dapmo/preview/e/3/6/9/8/5/3','3e6fa7413fad17b5fec9341b3be05f76',102,'3',2,1,-1,1665766152,1665766152,0,0,'634993084b241',31,''),(107,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_text.svg','e38f463b04b18d264a96b1030644541d',87,'icon-core-filetypes_text.svg',22,9,295,1665766154,1665766154,0,0,'1f14e1e7c057bd0328931f04bcb3c03f',27,''),(108,1,'appdata_occlus6dapmo/preview/a','6b38cbae3893effc609a5f90a8709b09',84,'a',2,1,-1,1665766152,1665766152,0,0,'6349930a16654',31,''),(109,1,'appdata_occlus6dapmo/preview/d/6/4/5/9/2/0','d02e9f777bfd1facfccd1dab773d734e',105,'0',2,1,-1,1665766152,1665766152,0,0,'6349930877e35',31,''),(110,1,'appdata_occlus6dapmo/preview/a/5','2e49e0d5a44e68261deec3b845a73183',108,'5',2,1,-1,1665766152,1665766152,0,0,'63499309e5e60',31,''),(111,1,'appdata_occlus6dapmo/preview/e/3/6/9/8/5/3/34','346910d2171dc40ff275054722e92b4f',106,'34',2,1,0,1665766161,1665766161,0,0,'6349930823e5a',31,''),(112,1,'appdata_occlus6dapmo/preview/d/6/4/5/9/2/0/40','4dec594481e3441da916c4b627ab3f6b',109,'40',2,1,0,1665766157,1665766157,0,0,'6349930856137',31,''),(113,1,'appdata_occlus6dapmo/preview/a/5/b','dd3f57c71b26cc96a896a1492715a239',110,'b',2,1,-1,1665766152,1665766152,0,0,'63499309c213a',31,''),(114,1,'appdata_occlus6dapmo/preview/a/5/b/f','c6b04a0a5818ea50dd18b22605410cb4',113,'f',2,1,-1,1665766152,1665766152,0,0,'63499309865a9',31,''),(115,1,'appdata_occlus6dapmo/preview/a/5/b/f/c','e0604230e6998a8919a15f7bd51e0c9b',114,'c',2,1,-1,1665766152,1665766152,0,0,'6349930959ca9',31,''),(116,1,'appdata_occlus6dapmo/preview/a/5/b/f/c/9','d0e5d6a251787674ae6beeb054223d53',115,'9',2,1,-1,1665766152,1665766152,0,0,'634993093981b',31,''),(117,1,'appdata_occlus6dapmo/preview/a/5/b/f/c/9/e','fa632499ee8813cae94c763ae9691042',116,'e',2,1,-1,1665766152,1665766152,0,0,'63499308f0c6d',31,''),(118,1,'appdata_occlus6dapmo/preview/a/5/b/f/c/9/e/37','489a87fbd7a51880784f9f97f257d015',117,'37',2,1,0,1665766158,1665766158,0,0,'63499308bb1de',31,''),(119,1,'appdata_occlus6dapmo/preview/d/6/4/5/9/2/0/40/500-500-max.png','af6e867d0e45de57f5ec2682727669fb',112,'500-500-max.png',18,9,50545,1665766156,1665766156,0,0,'2d269b39f8b379e1ff9a90d6c97cbc9c',27,''),(120,1,'appdata_occlus6dapmo/preview/d/6/4/5/9/2/0/40/256-256-crop.png','9f3829361e394da6e50a833b4eb093f0',112,'256-256-crop.png',18,9,24388,1665766157,1665766157,0,0,'47845c81b1ba846f8bb8a30bf8200d0b',27,''),(121,1,'appdata_occlus6dapmo/preview/e/3/6/9/8/5/3/34/4096-4096-max.png','7674c96f5ccb72408b897053e713d81c',111,'4096-4096-max.png',18,9,68696,1665766157,1665766157,0,0,'ac5beb555bddd02e93b4561cb6a61d48',27,''),(122,1,'appdata_occlus6dapmo/preview/a/5/b/f/c/9/e/37/256-144-max.png','1ec8cdc039a888fea5b383f26711c3df',118,'256-144-max.png',18,9,2197,1665766157,1665766157,0,0,'712184fa95c5b58d79e2be8b041d94c0',27,''),(123,1,'appdata_occlus6dapmo/preview/a/5/b/f/c/9/e/37/144-144-crop.png','e3b410bdf041f6d8fc1262a3bf3c0faa',118,'144-144-crop.png',18,9,5409,1665766158,1665766158,0,0,'159f24b0dfcc6a79bc76bfc6d6a09d19',27,''),(124,1,'appdata_occlus6dapmo/preview/e/3/6/9/8/5/3/34/256-256-crop.png','ec009bc578aa585d3616392c0cde5cfa',111,'256-256-crop.png',18,9,12062,1665766161,1665766161,0,0,'997d6584d17b1ab62dc60dfc29c620bc',27,''),(125,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-server.css','659a499d2586f8579881eb1ba93bd65d',49,'7fcc-b0c4-server.css',21,5,139049,1665767030,1665767030,0,0,'8eb34447732ece06526ac33e6475e902',27,''),(126,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-server.css.deps','b288b66d70d22097a02faae3e585f545',49,'7fcc-b0c4-server.css.deps',14,3,759,1665767031,1665767031,0,0,'4dde1b43cbd741cbb2164b2ab80d4aff',27,''),(127,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-server.css.gzip','2426f768429c01d3d6550afb056ce86b',49,'7fcc-b0c4-server.css.gzip',20,3,19855,1665767031,1665767031,0,0,'6b5907208b4cdb77806ff4efd916f1e2',27,''),(128,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-css-variables.css','e1a2319e5fcc2146988a68b57c57a9b0',49,'7fcc-b0c4-css-variables.css',21,5,1820,1665767031,1665767031,0,0,'ff24b3f64a41f0899631f8585451d4f7',27,''),(129,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-css-variables.css.deps','8ef29e11d8b49e9034fdce1e13bd8695',49,'7fcc-b0c4-css-variables.css.deps',14,3,176,1665767032,1665767032,0,0,'b9f4d3030ed1de5833c3f0c45ebdf886',27,''),(130,1,'appdata_occlus6dapmo/css/core/7fcc-b0c4-css-variables.css.gzip','3cffa95b2c871d01f381390197179652',49,'7fcc-b0c4-css-variables.css.gzip',20,3,692,1665767032,1665767032,0,0,'8516c65b7e893596e35b137b6df07b77',27,''),(131,1,'appdata_occlus6dapmo/css/dashboard/1c83-b0c4-dashboard.css','b2d6ba5321dac4bae5e7ce77da61a90c',62,'1c83-b0c4-dashboard.css',21,5,2050,1665767032,1665767032,0,0,'c5456fd50281c512c916da5990e2d7f0',27,''),(132,1,'appdata_occlus6dapmo/css/dashboard/1c83-b0c4-dashboard.css.deps','344819dddfd04297491eb04e10bb662c',62,'1c83-b0c4-dashboard.css.deps',14,3,183,1665767033,1665767033,0,0,'7fa14a935ddc492742208164fd995bea',27,''),(133,1,'appdata_occlus6dapmo/css/dashboard/1c83-b0c4-dashboard.css.gzip','e1a9c1e7df2a91d56918776eef68014b',62,'1c83-b0c4-dashboard.css.gzip',20,3,594,1665767033,1665767033,0,0,'1b4ff3d6465448ae0e891dc2389dc9b2',27,''),(134,1,'appdata_occlus6dapmo/css/activity/6e52-b0c4-style.css','494dc19abd5e28eb30cb3ab1a763edf8',66,'6e52-b0c4-style.css',21,5,3353,1665767033,1665767033,0,0,'c6c4184216f0e1fc239f0e4ccf40b07e',27,''),(135,1,'appdata_occlus6dapmo/css/activity/6e52-b0c4-style.css.deps','dd746d03168bfe4535b3f424f0fe6534',66,'6e52-b0c4-style.css.deps',14,3,178,1665767033,1665767033,0,0,'283b8a0f299b1d2e4ff32b0f93db4b53',27,''),(136,1,'appdata_occlus6dapmo/css/activity/6e52-b0c4-style.css.gzip','bf46f34b4d331551bed965af0dcdc529',66,'6e52-b0c4-style.css.gzip',20,3,1108,1665767034,1665767034,0,0,'cf57e7b569133f55bb4bfb189cdbb01b',27,''),(137,1,'appdata_occlus6dapmo/css/text/8931-b0c4-icons.css','33bd76d0003dbf577555d1d6b794e1a4',70,'8931-b0c4-icons.css',21,5,5861,1665767034,1665767034,0,0,'b30834c1d7c4e8ffb905b868e7e25da7',27,''),(138,1,'appdata_occlus6dapmo/css/text/8931-b0c4-icons.css.deps','1e1d156c1176bfbc0ac29b0841bd787b',70,'8931-b0c4-icons.css.deps',14,3,174,1665767034,1665767034,0,0,'203eded29668fadfc78236ed8b5627eb',27,''),(139,1,'appdata_occlus6dapmo/css/text/8931-b0c4-icons.css.gzip','57f8c60e7c1d714886fd1e779640ce60',70,'8931-b0c4-icons.css.gzip',20,3,832,1665767035,1665767035,0,0,'d593692a9cf85b1c99b1eb8fa7c51fc8',27,''),(140,1,'appdata_occlus6dapmo/css/notifications/ae3e-b0c4-styles.css','a8a517ea7b6a8a4437ab395cc342471a',74,'ae3e-b0c4-styles.css',21,5,5377,1665767035,1665767035,0,0,'1fac89ed7ef6d0aeafbbbad5267f6dcb',27,''),(141,1,'appdata_occlus6dapmo/css/notifications/ae3e-b0c4-styles.css.deps','24c2019ab17003e4c3cce7204ca95381',74,'ae3e-b0c4-styles.css.deps',14,3,184,1665767035,1665767035,0,0,'ad32b53832414a94f54bef684388c0a5',27,''),(142,1,'appdata_occlus6dapmo/css/notifications/ae3e-b0c4-styles.css.gzip','5551a1ae1dff546c284ce19c05757301',74,'ae3e-b0c4-styles.css.gzip',20,3,1176,1665767035,1665767035,0,0,'4d8b974f0685ea36df12955936d0bbd4',27,''),(143,1,'appdata_occlus6dapmo/css/user_status/1bf6-b0c4-user-status-menu.css','3973ae8630554be95ef936581b8eb76f',78,'1bf6-b0c4-user-status-menu.css',21,5,999,1665767036,1665767036,0,0,'370ed6d8e6cf23b6b839195e953f5bc4',27,''),(144,1,'appdata_occlus6dapmo/css/user_status/1bf6-b0c4-user-status-menu.css.deps','4fc6bddddeea0c16e29d44062918c1cd',78,'1bf6-b0c4-user-status-menu.css.deps',14,3,192,1665767036,1665767036,0,0,'d3fc54798137c2f94cd8a28830c9f758',27,''),(145,1,'appdata_occlus6dapmo/css/user_status/1bf6-b0c4-user-status-menu.css.gzip','36be56a79a1da357198cba23226b4fc1',78,'1bf6-b0c4-user-status-menu.css.gzip',20,3,232,1665767036,1665767036,0,0,'71f260a0bd7119872e4b2816edf2462b',27,''),(146,1,'appdata_occlus6dapmo/css/theming/d71e-b0c4-theming.css','f0457b9987c6182b5baacfab8f97fce8',58,'d71e-b0c4-theming.css',21,5,1764,1665772008,1665772008,0,0,'c45ab13075f68f2e6a4696a51692fcf8',27,''),(147,1,'appdata_occlus6dapmo/css/theming/d71e-b0c4-theming.css.deps','09759235222e54c2f1f7dca3a2fb16e8',58,'d71e-b0c4-theming.css.deps',14,3,179,1665772008,1665772008,0,0,'650e52ccdeac9fdf9322a00d6f85a8db',27,''),(148,1,'appdata_occlus6dapmo/css/theming/d71e-b0c4-theming.css.gzip','92f8de8559da0e77cdc8a9823f329be7',58,'d71e-b0c4-theming.css.gzip',20,3,527,1665772009,1665772009,0,0,'cd430edd2827f8d0c6476b9b9267c54c',27,''),(149,2,'cache','0fea6a13c52b4d4725368f24b045ca84',5,'cache',2,1,0,1529666681,1529666681,0,0,'5b2cdc79b2440',31,''),(150,1,'appdata_occlus6dapmo/css/theming/d71e-273f-theming.css','d41bcc93575abecb61efbe4f1e6fcca7',58,'d71e-273f-theming.css',21,5,1764,1529667044,1529667044,0,0,'fe161586520e87b3092de087392a86a5',27,''),(151,1,'appdata_occlus6dapmo/css/theming/d71e-273f-theming.css.deps','cd5ac19fca5c02bc180e8994853db2ff',58,'d71e-273f-theming.css.deps',14,3,179,1529667044,1529667044,0,0,'46cb73a8cbb7c8276b241a27734661a9',27,''),(152,1,'appdata_occlus6dapmo/css/theming/d71e-273f-theming.css.gzip','507e746ebfa02fe1909077214b2eedb5',58,'d71e-273f-theming.css.gzip',20,3,527,1529667044,1529667044,0,0,'65842a6330d65f2d827e96cfc8d6d664',27,''),(153,1,'appdata_occlus6dapmo/css/core/7fcc-273f-server.css','c9da09e45c47d90da1c25a64852f6631',49,'7fcc-273f-server.css',21,5,139049,1529667068,1529667068,0,0,'f6245288cc51ffa839c7507c641dac6a',27,''),(154,1,'appdata_occlus6dapmo/css/core/7fcc-273f-server.css.deps','6a108ca5ac4ea8e1a56108663298ba87',49,'7fcc-273f-server.css.deps',14,3,759,1529667068,1529667068,0,0,'6c6148a71669107fde3dc04dc0e690b8',27,''),(155,1,'appdata_occlus6dapmo/css/core/7fcc-273f-server.css.gzip','ffb4ddca21956a62409beadb41693376',49,'7fcc-273f-server.css.gzip',20,3,19855,1529667069,1529667069,0,0,'fd32d7d71cb1fa0658774b366e80b976',27,''),(156,1,'appdata_occlus6dapmo/css/core/7fcc-273f-css-variables.css','66bd567e86c91c8589b540da04287574',49,'7fcc-273f-css-variables.css',21,5,1820,1529667069,1529667069,0,0,'b5036a24891fece78f746b879dd85754',27,''),(157,1,'appdata_occlus6dapmo/css/core/7fcc-273f-css-variables.css.deps','f7fc8cdba28566672a7b5413eac55952',49,'7fcc-273f-css-variables.css.deps',14,3,176,1529667070,1529667070,0,0,'fd72e3b167729641b84b34c434e13e2b',27,''),(158,1,'appdata_occlus6dapmo/css/core/7fcc-273f-css-variables.css.gzip','067ebf189e9f07d469319536f8b850cd',49,'7fcc-273f-css-variables.css.gzip',20,3,692,1529667070,1529667070,0,0,'f664d6d13830eff214af9c165d0a1b0a',27,''),(159,1,'appdata_occlus6dapmo/css/dashboard/1c83-273f-dashboard.css','0f02d3e1382dee44adbb0d49e6cefe0c',62,'1c83-273f-dashboard.css',21,5,2050,1529667070,1529667070,0,0,'015d37b06f6103d32c120356b8b8acbc',27,''),(160,1,'appdata_occlus6dapmo/css/dashboard/1c83-273f-dashboard.css.deps','c63d1f4f496231823607b3f7c711dc7b',62,'1c83-273f-dashboard.css.deps',14,3,183,1529667070,1529667070,0,0,'4f3d2ea9b51f3c4b32081d2ef9392211',27,''),(161,1,'appdata_occlus6dapmo/css/dashboard/1c83-273f-dashboard.css.gzip','c980177dc8cadd0797039742e720fe5c',62,'1c83-273f-dashboard.css.gzip',20,3,594,1529667070,1529667070,0,0,'6f5f95044f49df1ae413ab799ad7bd75',27,''),(162,1,'appdata_occlus6dapmo/css/activity/6e52-273f-style.css','72bb346d0c94c47abb590bcae99ea4d0',66,'6e52-273f-style.css',21,5,3353,1529667071,1529667071,0,0,'b61986526c129398f45131d7f4b653f5',27,''),(163,1,'appdata_occlus6dapmo/css/activity/6e52-273f-style.css.deps','17385cb382dca4e307a24f65864a3633',66,'6e52-273f-style.css.deps',14,3,178,1529667071,1529667071,0,0,'19e2de51a7ebd1f116c4ad14991d095a',27,''),(164,1,'appdata_occlus6dapmo/css/activity/6e52-273f-style.css.gzip','431fb7e09fce6e71afc75cb206d79cb1',66,'6e52-273f-style.css.gzip',20,3,1108,1529667071,1529667071,0,0,'5040ff21ae6ad9bfa8b5cfe99ad4134c',27,''),(165,1,'appdata_occlus6dapmo/css/text/8931-273f-icons.css','6735bfdab0bd9730a7da7f3f34ab92b6',70,'8931-273f-icons.css',21,5,5861,1529667072,1529667072,0,0,'2eabe48e0cc2f73dc0f889b9e712b2d7',27,''),(166,1,'appdata_occlus6dapmo/css/text/8931-273f-icons.css.deps','5b35b7ee05e9825e58e7f78f0c505a3a',70,'8931-273f-icons.css.deps',14,3,174,1529667072,1529667072,0,0,'6cc8da9b604d1796b2f7c3be80be339c',27,''),(167,1,'appdata_occlus6dapmo/css/text/8931-273f-icons.css.gzip','e00d442f82d93d08c624cdd62c9ab888',70,'8931-273f-icons.css.gzip',20,3,832,1529667072,1529667072,0,0,'c2a8a9f708ba76de32dc09b63d336995',27,''),(168,1,'appdata_occlus6dapmo/css/notifications/ae3e-273f-styles.css','9354003cfd663b66e8850aac3953cdca',74,'ae3e-273f-styles.css',21,5,5377,1529667072,1529667072,0,0,'ecdc2da5f4958fa7368ce71847c8dc46',27,''),(169,1,'appdata_occlus6dapmo/css/notifications/ae3e-273f-styles.css.deps','7d31db88d1004dcda4ac765b3a519a6e',74,'ae3e-273f-styles.css.deps',14,3,184,1529667073,1529667073,0,0,'8c4f72d8b646f13e19531d2d165fd41d',27,''),(170,1,'appdata_occlus6dapmo/css/notifications/ae3e-273f-styles.css.gzip','5b2fa977e86081a277a8068f3fe6539c',74,'ae3e-273f-styles.css.gzip',20,3,1176,1529667073,1529667073,0,0,'e35194bc4111bdb00679cafa5e495586',27,''),(171,1,'appdata_occlus6dapmo/css/user_status/1bf6-273f-user-status-menu.css','791f1e249266a3d68911a3a05edab45d',78,'1bf6-273f-user-status-menu.css',21,5,999,1529667073,1529667073,0,0,'9fdd8cdedabcdf071a5c23476d1843db',27,''),(172,1,'appdata_occlus6dapmo/css/user_status/1bf6-273f-user-status-menu.css.deps','c107a897d65677358555d8549ac0e6a0',78,'1bf6-273f-user-status-menu.css.deps',14,3,192,1529667074,1529667074,0,0,'982010934830a0804bf9b37db14b6e1e',27,''),(173,1,'appdata_occlus6dapmo/css/user_status/1bf6-273f-user-status-menu.css.gzip','b8a3a79544833f0117631d10d41e77fc',78,'1bf6-273f-user-status-menu.css.gzip',20,3,232,1529667074,1529667074,0,0,'51290feb7ae526cbe3ad3374f001bdff',27,''),(174,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_image.svg','233a54bb9ededfb8f35e2e6b6d382656',87,'icon-core-filetypes_image.svg',22,9,352,1529667089,1529667089,0,0,'a604b893668a05b3f7a2695ecbb03de2',27,''),(175,1,'appdata_occlus6dapmo/js/files','675bf822617092537c42a2a2347f664d',42,'files',2,1,0,1666028861,1666028861,0,0,'634d953c1911d',31,''),(176,1,'appdata_occlus6dapmo/js/files/merged-index.js','25aae9b9623bceefe72a224ce95020ee',175,'merged-index.js',19,3,421868,1666028860,1666028860,0,0,'f743a755d3a19fcdc5308661eafb310a',27,''),(177,1,'appdata_occlus6dapmo/js/files/merged-index.js.deps','6eeb9a5624a7a33c28acccbadb9c4f30',175,'merged-index.js.deps',14,3,2024,1666028860,1666028860,0,0,'fc782d8b248782579b477b43f79b28a8',27,''),(178,1,'appdata_occlus6dapmo/js/files/merged-index.js.gzip','3c594b0762525bf704ff9ea4af609373',175,'merged-index.js.gzip',20,3,95539,1666028861,1666028861,0,0,'044fb4b2138896ce1a1cb1f7185e9dff',27,''),(179,1,'appdata_occlus6dapmo/css/files','67c48e5bbaead1097a324d9401c7e71e',47,'files',2,1,0,1666028863,1666028863,0,0,'634d953dcde27',31,''),(180,1,'appdata_occlus6dapmo/css/files/f244-273f-merged.css','ff399dabf6eea93085d6ebdb6afe061e',179,'f244-273f-merged.css',21,5,30015,1666028863,1666028863,0,0,'acd7ff0da4b6d891173235bcc44acf0e',27,''),(181,1,'appdata_occlus6dapmo/css/files/f244-273f-merged.css.deps','00ece6dbdf18981bf9f1ec5d6928218a',179,'f244-273f-merged.css.deps',14,3,480,1666028863,1666028863,0,0,'2ec39ad2d592b14499c7ad93db53a12d',27,''),(182,1,'appdata_occlus6dapmo/css/files/f244-273f-merged.css.gzip','e3c36633c9eabdea089c50c8b5c95611',179,'f244-273f-merged.css.gzip',20,3,5872,1666028863,1666028863,0,0,'b28050daf28a2bc179f76222a9064867',27,''),(183,1,'appdata_occlus6dapmo/css/files_sharing','bd64b5ea3642a01cfc016639e180b490',47,'files_sharing',2,1,0,1666028864,1666028864,0,0,'634d953f8fe6f',31,''),(184,1,'appdata_occlus6dapmo/css/files_sharing/9b08-273f-icons.css','c1ad3372c5fd640dd55e186913015a8e',183,'9b08-273f-icons.css',21,5,174,1666028864,1666028864,0,0,'88b8f5e6e975bffcacc31bc38805dd30',27,''),(185,1,'appdata_occlus6dapmo/css/files_sharing/9b08-273f-icons.css.deps','f58f4749a58e8c927613f67b33ef519e',183,'9b08-273f-icons.css.deps',14,3,183,1666028864,1666028864,0,0,'0aaaad61ce8b05ac8f39cd08618c2712',27,''),(186,1,'appdata_occlus6dapmo/css/files_sharing/9b08-273f-icons.css.gzip','caf982551e9164dede2f96b623f99e84',183,'9b08-273f-icons.css.gzip',20,3,102,1666028864,1666028864,0,0,'3104cfb575bc0be6ab0b47ab523d25fa',27,''),(187,1,'appdata_occlus6dapmo/theming/0/icon-core-filetypes_folder.svg','776f24af535627f27b67ef58674edbc0',87,'icon-core-filetypes_folder.svg',22,9,255,1666028870,1666028870,0,0,'461efc4b76d57375a0ea6f55fd4bd8d9',27,'');
/*!40000 ALTER TABLE `oc_filecache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache_extended`
--

DROP TABLE IF EXISTS `oc_filecache_extended`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_filecache_extended` (
  `fileid` bigint unsigned NOT NULL,
  `metadata_etag` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `creation_time` bigint NOT NULL DEFAULT '0',
  `upload_time` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`fileid`),
  KEY `fce_ctime_idx` (`creation_time`),
  KEY `fce_utime_idx` (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache_extended`
--

LOCK TABLES `oc_filecache_extended` WRITE;
/*!40000 ALTER TABLE `oc_filecache_extended` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_filecache_extended` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_trash`
--

DROP TABLE IF EXISTS `oc_files_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_trash` (
  `auto_id` bigint NOT NULL AUTO_INCREMENT,
  `id` varchar(250) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `user` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `timestamp` varchar(12) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `location` varchar(512) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(4) COLLATE utf8mb4_bin DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  KEY `id_index` (`id`),
  KEY `timestamp_index` (`timestamp`),
  KEY `user_index` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_trash`
--

LOCK TABLES `oc_files_trash` WRITE;
/*!40000 ALTER TABLE `oc_files_trash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_trash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_checks`
--

DROP TABLE IF EXISTS `oc_flow_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_checks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `class` varchar(256) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `operator` varchar(16) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `value` longtext COLLATE utf8mb4_bin,
  `hash` varchar(32) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flow_unique_hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_checks`
--

LOCK TABLES `oc_flow_checks` WRITE;
/*!40000 ALTER TABLE `oc_flow_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_operations`
--

DROP TABLE IF EXISTS `oc_flow_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `class` varchar(256) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `name` varchar(256) COLLATE utf8mb4_bin DEFAULT '',
  `checks` longtext COLLATE utf8mb4_bin,
  `operation` longtext COLLATE utf8mb4_bin,
  `entity` varchar(256) COLLATE utf8mb4_bin NOT NULL DEFAULT 'OCA\\WorkflowEngine\\Entity\\File',
  `events` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_operations`
--

LOCK TABLES `oc_flow_operations` WRITE;
/*!40000 ALTER TABLE `oc_flow_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_operations_scope`
--

DROP TABLE IF EXISTS `oc_flow_operations_scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_operations_scope` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` int NOT NULL DEFAULT '0',
  `type` int NOT NULL DEFAULT '0',
  `value` varchar(64) COLLATE utf8mb4_bin DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flow_unique_scope` (`operation_id`,`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_operations_scope`
--

LOCK TABLES `oc_flow_operations_scope` WRITE;
/*!40000 ALTER TABLE `oc_flow_operations_scope` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_operations_scope` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_admin`
--

DROP TABLE IF EXISTS `oc_group_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_group_admin` (
  `gid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `group_admin_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_admin`
--

LOCK TABLES `oc_group_admin` WRITE;
/*!40000 ALTER TABLE `oc_group_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_group_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_user`
--

DROP TABLE IF EXISTS `oc_group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_group_user` (
  `gid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `gu_uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_user`
--

LOCK TABLES `oc_group_user` WRITE;
/*!40000 ALTER TABLE `oc_group_user` DISABLE KEYS */;
INSERT INTO `oc_group_user` VALUES ('admin','atlas');
/*!40000 ALTER TABLE `oc_group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_groups`
--

DROP TABLE IF EXISTS `oc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_groups` (
  `gid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `displayname` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT 'name',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_groups`
--

LOCK TABLES `oc_groups` WRITE;
/*!40000 ALTER TABLE `oc_groups` DISABLE KEYS */;
INSERT INTO `oc_groups` VALUES ('admin','admin');
/*!40000 ALTER TABLE `oc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_jobs`
--

DROP TABLE IF EXISTS `oc_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `argument` varchar(4000) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `last_run` int DEFAULT '0',
  `last_checked` int DEFAULT '0',
  `reserved_at` int DEFAULT '0',
  `execution_duration` int DEFAULT '0',
  `argument_hash` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `time_sensitive` smallint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `job_class_index` (`class`),
  KEY `job_lastcheck_reserved` (`last_checked`,`reserved_at`),
  KEY `job_argument_hash` (`class`,`argument_hash`),
  KEY `jobs_time_sensitive` (`time_sensitive`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_jobs`
--

LOCK TABLES `oc_jobs` WRITE;
/*!40000 ALTER TABLE `oc_jobs` DISABLE KEYS */;
INSERT INTO `oc_jobs` VALUES (1,'OCA\\Activity\\BackgroundJob\\EmailNotification','null',1665766133,1665766133,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(2,'OCA\\Activity\\BackgroundJob\\ExpireActivities','null',1665766150,1665766150,0,0,'37a6259cc0c1dae299a7866489dff0bd',0),(3,'OCA\\Activity\\BackgroundJob\\DigestMail','null',1665772012,1665772012,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(4,'OCA\\Circles\\Cron\\Maintenance','null',1665780896,1665780896,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(5,'OCA\\ContactsInteraction\\BackgroundJob\\CleanupJob','null',1666024832,1666024832,0,0,'37a6259cc0c1dae299a7866489dff0bd',0),(6,'OCA\\DAV\\BackgroundJob\\CleanupDirectLinksJob','null',1666028867,1666028867,0,0,'37a6259cc0c1dae299a7866489dff0bd',0),(7,'OCA\\DAV\\BackgroundJob\\UpdateCalendarResourcesRoomsBackgroundJob','null',1666031922,1666031922,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(8,'OCA\\DAV\\BackgroundJob\\CleanupInvitationTokenJob','null',1666120872,1666120871,0,0,'37a6259cc0c1dae299a7866489dff0bd',0),(9,'OCA\\DAV\\BackgroundJob\\EventReminderJob','null',1666121794,1666121793,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(10,'OCA\\DAV\\BackgroundJob\\CalendarRetentionJob','null',0,1665765886,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(11,'OCA\\Federation\\SyncJob','null',0,1665765902,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(12,'OCA\\Files\\BackgroundJob\\ScanFiles','null',0,1665765909,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(13,'OCA\\Files\\BackgroundJob\\DeleteOrphanedItems','null',0,1665765910,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(14,'OCA\\Files\\BackgroundJob\\CleanupFileLocks','null',0,1665765910,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(15,'OCA\\Files\\BackgroundJob\\CleanupDirectEditingTokens','null',0,1665765910,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(16,'OCA\\Files_Sharing\\DeleteOrphanedSharesJob','null',0,1665765921,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(17,'OCA\\Files_Sharing\\ExpireSharesJob','null',0,1665765921,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(18,'OCA\\Files_Sharing\\BackgroundJob\\FederatedSharesDiscoverJob','null',0,1665765922,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(19,'OCA\\Files_Trashbin\\BackgroundJob\\ExpireTrash','null',0,1665765931,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(20,'OCA\\Files_Versions\\BackgroundJob\\ExpireVersions','null',0,1665765931,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(21,'OCA\\NextcloudAnnouncements\\Cron\\Crawler','null',0,1665765933,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(22,'OCA\\Notifications\\BackgroundJob\\GenerateUserSettings','null',0,1665765944,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(23,'OCA\\Notifications\\BackgroundJob\\SendNotificationMails','null',0,1665765944,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(24,'OCA\\ServerInfo\\Jobs\\UpdateStorageStats','null',0,1665765968,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(25,'OCA\\Support\\BackgroundJobs\\CheckSubscription','null',0,1665765969,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(26,'OCA\\Text\\Cron\\Cleanup','null',0,1665765983,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(27,'OCA\\UpdateNotification\\Notification\\BackgroundJob','null',0,1665765993,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(28,'OCA\\UserStatus\\BackgroundJob\\ClearOldStatusesBackgroundJob','null',0,1665766003,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(29,'OCA\\WorkflowEngine\\BackgroundJobs\\Rotate','null',0,1665766019,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(30,'OC\\Authentication\\Token\\TokenCleanupJob','null',0,1665766039,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(31,'OC\\Log\\Rotate','null',0,1665766039,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(32,'OC\\Preview\\BackgroundCleanupJob','null',0,1665766039,0,0,'37a6259cc0c1dae299a7866489dff0bd',1),(33,'OCA\\FirstRunWizard\\Notification\\BackgroundJob','{\"uid\":\"atlas\"}',0,1665766138,0,0,'b9650a9440b8cf6ae44f9dab862b164c',1);
/*!40000 ALTER TABLE `oc_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_known_users`
--

DROP TABLE IF EXISTS `oc_known_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_known_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `known_to` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `known_user` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ku_known_to` (`known_to`),
  KEY `ku_known_user` (`known_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_known_users`
--

LOCK TABLES `oc_known_users` WRITE;
/*!40000 ALTER TABLE `oc_known_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_known_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_login_flow_v2`
--

DROP TABLE IF EXISTS `oc_login_flow_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_login_flow_v2` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` bigint unsigned NOT NULL,
  `started` smallint unsigned NOT NULL DEFAULT '0',
  `poll_token` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `login_token` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `public_key` text COLLATE utf8mb4_bin NOT NULL,
  `private_key` text COLLATE utf8mb4_bin NOT NULL,
  `client_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `login_name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `server` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `app_password` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `poll_token` (`poll_token`),
  UNIQUE KEY `login_token` (`login_token`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_login_flow_v2`
--

LOCK TABLES `oc_login_flow_v2` WRITE;
/*!40000 ALTER TABLE `oc_login_flow_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_login_flow_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_migrations`
--

DROP TABLE IF EXISTS `oc_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_migrations` (
  `app` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`app`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_migrations`
--

LOCK TABLES `oc_migrations` WRITE;
/*!40000 ALTER TABLE `oc_migrations` DISABLE KEYS */;
INSERT INTO `oc_migrations` VALUES ('activity','2006Date20170808154933'),('activity','2006Date20170808155040'),('activity','2006Date20170919095939'),('activity','2007Date20181107114613'),('activity','2008Date20181011095117'),('activity','2010Date20190416112817'),('activity','2011Date20201006132544'),('activity','2011Date20201006132545'),('activity','2011Date20201006132546'),('activity','2011Date20201006132547'),('activity','2011Date20201207091915'),('circles','0022Date20220526111723'),('circles','0022Date20220526113601'),('circles','0022Date20220703115023'),('circles','0023Date20211216113101'),('circles','0024Date20220203123901'),('circles','0024Date20220203123902'),('circles','0024Date20220317190331'),('contactsinteraction','010000Date20200304152605'),('core','13000Date20170705121758'),('core','13000Date20170718121200'),('core','13000Date20170814074715'),('core','13000Date20170919121250'),('core','13000Date20170926101637'),('core','14000Date20180129121024'),('core','14000Date20180404140050'),('core','14000Date20180516101403'),('core','14000Date20180518120534'),('core','14000Date20180522074438'),('core','14000Date20180626223656'),('core','14000Date20180710092004'),('core','14000Date20180712153140'),('core','15000Date20180926101451'),('core','15000Date20181015062942'),('core','15000Date20181029084625'),('core','16000Date20190207141427'),('core','16000Date20190212081545'),('core','16000Date20190427105638'),('core','16000Date20190428150708'),('core','17000Date20190514105811'),('core','18000Date20190920085628'),('core','18000Date20191014105105'),('core','18000Date20191204114856'),('core','19000Date20200211083441'),('core','20000Date20201109081915'),('core','20000Date20201109081918'),('core','20000Date20201109081919'),('core','20000Date20201111081915'),('core','21000Date20201120141228'),('core','21000Date20201202095923'),('core','21000Date20210119195004'),('core','21000Date20210309185126'),('core','21000Date20210309185127'),('core','22000Date20210216080825'),('core','23000Date20210721100600'),('core','23000Date20210906132259'),('core','23000Date20210930122352'),('core','23000Date20211203110726'),('core','23000Date20211213203940'),('core','24000Date20211210141942'),('core','24000Date20211213081506'),('core','24000Date20211213081604'),('core','24000Date20211222112246'),('core','24000Date20211230140012'),('core','24000Date20220131153041'),('core','24000Date20220202150027'),('core','24000Date20220404230027'),('core','24000Date20220425072957'),('core','25000Date20220515204012'),('dav','1004Date20170825134824'),('dav','1004Date20170919104507'),('dav','1004Date20170924124212'),('dav','1004Date20170926103422'),('dav','1005Date20180413093149'),('dav','1005Date20180530124431'),('dav','1006Date20180619154313'),('dav','1006Date20180628111625'),('dav','1008Date20181030113700'),('dav','1008Date20181105104826'),('dav','1008Date20181105104833'),('dav','1008Date20181105110300'),('dav','1008Date20181105112049'),('dav','1008Date20181114084440'),('dav','1011Date20190725113607'),('dav','1011Date20190806104428'),('dav','1012Date20190808122342'),('dav','1016Date20201109085907'),('dav','1017Date20210216083742'),('dav','1018Date20210312100735'),('federatedfilesharing','1010Date20200630191755'),('federatedfilesharing','1011Date20201120125158'),('federation','1010Date20200630191302'),('files','11301Date20191205150729'),('files_sharing','11300Date20201120141438'),('files_sharing','21000Date20201223143245'),('files_sharing','22000Date20210216084241'),('files_sharing','24000Date20220208195521'),('files_sharing','24000Date20220404142216'),('files_trashbin','1010Date20200630192639'),('notifications','2004Date20190107135757'),('notifications','2010Date20210218082811'),('notifications','2010Date20210218082855'),('notifications','2011Date20210930134607'),('notifications','2011Date20220826074907'),('oauth2','010401Date20181207190718'),('oauth2','010402Date20190107124745'),('privacy','100Date20190217131943'),('text','010000Date20190617184535'),('text','030001Date20200402075029'),('text','030201Date20201116110353'),('text','030201Date20201116123153'),('text','030501Date20220202101853'),('twofactor_backupcodes','1002Date20170607104347'),('twofactor_backupcodes','1002Date20170607113030'),('twofactor_backupcodes','1002Date20170919123342'),('twofactor_backupcodes','1002Date20170926101419'),('twofactor_backupcodes','1002Date20180821043638'),('user_status','0001Date20200602134824'),('user_status','0002Date20200902144824'),('user_status','1000Date20201111130204'),('user_status','2301Date20210809144824'),('workflowengine','2000Date20190808074233'),('workflowengine','2200Date20210805101925');
/*!40000 ALTER TABLE `oc_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mimetypes`
--

DROP TABLE IF EXISTS `oc_mimetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_mimetypes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mimetype` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mimetype_id_index` (`mimetype`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mimetypes`
--

LOCK TABLES `oc_mimetypes` WRITE;
/*!40000 ALTER TABLE `oc_mimetypes` DISABLE KEYS */;
INSERT INTO `oc_mimetypes` VALUES (3,'application'),(19,'application/javascript'),(4,'application/json'),(14,'application/octet-stream'),(7,'application/pdf'),(11,'application/vnd.oasis.opendocument.graphics'),(13,'application/vnd.oasis.opendocument.presentation'),(12,'application/vnd.oasis.opendocument.spreadsheet'),(15,'application/vnd.oasis.opendocument.text'),(8,'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(20,'application/x-gzip'),(1,'httpd'),(2,'httpd/unix-directory'),(9,'image'),(10,'image/jpeg'),(18,'image/png'),(22,'image/svg+xml'),(5,'text'),(21,'text/css'),(6,'text/markdown'),(16,'video'),(17,'video/mp4');
/*!40000 ALTER TABLE `oc_mimetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mounts`
--

DROP TABLE IF EXISTS `oc_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_mounts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `storage_id` bigint NOT NULL,
  `root_id` bigint NOT NULL,
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `mount_point` varchar(4000) COLLATE utf8mb4_bin NOT NULL,
  `mount_id` bigint DEFAULT NULL,
  `mount_provider_class` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mounts_user_root_index` (`user_id`,`root_id`),
  KEY `mounts_storage_index` (`storage_id`),
  KEY `mounts_root_index` (`root_id`),
  KEY `mounts_mount_id_index` (`mount_id`),
  KEY `mount_user_storage` (`storage_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mounts`
--

LOCK TABLES `oc_mounts` WRITE;
/*!40000 ALTER TABLE `oc_mounts` DISABLE KEYS */;
INSERT INTO `oc_mounts` VALUES (1,2,5,'atlas','/atlas/',NULL,'OC\\Files\\Mount\\LocalHomeMountProvider');
/*!40000 ALTER TABLE `oc_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications`
--

DROP TABLE IF EXISTS `oc_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `user` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `timestamp` int NOT NULL DEFAULT '0',
  `object_type` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `object_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `subject` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `subject_parameters` longtext COLLATE utf8mb4_bin,
  `message` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `message_parameters` longtext COLLATE utf8mb4_bin,
  `link` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  `icon` varchar(4000) COLLATE utf8mb4_bin DEFAULT NULL,
  `actions` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`notification_id`),
  KEY `oc_notifications_app` (`app`),
  KEY `oc_notifications_user` (`user`),
  KEY `oc_notifications_timestamp` (`timestamp`),
  KEY `oc_notifications_object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications`
--

LOCK TABLES `oc_notifications` WRITE;
/*!40000 ALTER TABLE `oc_notifications` DISABLE KEYS */;
INSERT INTO `oc_notifications` VALUES (1,'firstrunwizard','atlas',1665766138,'app','groupfolders','apphint-groupfolders','[]','','[]','','','[]'),(2,'firstrunwizard','atlas',1665766138,'app','notes','apphint-notes','[]','','[]','','','[]'),(3,'firstrunwizard','atlas',1665766138,'app','deck','apphint-deck','[]','','[]','','','[]'),(4,'firstrunwizard','atlas',1665766139,'app','tasks','apphint-tasks','[]','','[]','','','[]');
/*!40000 ALTER TABLE `oc_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications_pushhash`
--

DROP TABLE IF EXISTS `oc_notifications_pushhash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications_pushhash` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `token` int NOT NULL DEFAULT '0',
  `deviceidentifier` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `devicepublickey` varchar(512) COLLATE utf8mb4_bin NOT NULL,
  `devicepublickeyhash` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `pushtokenhash` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `proxyserver` varchar(256) COLLATE utf8mb4_bin NOT NULL,
  `apptype` varchar(32) COLLATE utf8mb4_bin NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`),
  UNIQUE KEY `oc_npushhash_uid` (`uid`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications_pushhash`
--

LOCK TABLES `oc_notifications_pushhash` WRITE;
/*!40000 ALTER TABLE `oc_notifications_pushhash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_notifications_pushhash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications_settings`
--

DROP TABLE IF EXISTS `oc_notifications_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `batch_time` int NOT NULL DEFAULT '0',
  `last_send_id` bigint NOT NULL DEFAULT '0',
  `next_send_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `notset_user` (`user_id`),
  KEY `notset_nextsend` (`next_send_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications_settings`
--

LOCK TABLES `oc_notifications_settings` WRITE;
/*!40000 ALTER TABLE `oc_notifications_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_notifications_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_oauth2_access_tokens`
--

DROP TABLE IF EXISTS `oc_oauth2_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_oauth2_access_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `token_id` int NOT NULL,
  `client_id` int NOT NULL,
  `hashed_code` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `encrypted_token` varchar(786) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth2_access_hash_idx` (`hashed_code`),
  KEY `oauth2_access_client_id_idx` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_oauth2_access_tokens`
--

LOCK TABLES `oc_oauth2_access_tokens` WRITE;
/*!40000 ALTER TABLE `oc_oauth2_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_oauth2_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_oauth2_clients`
--

DROP TABLE IF EXISTS `oc_oauth2_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_oauth2_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `redirect_uri` varchar(2000) COLLATE utf8mb4_bin NOT NULL,
  `client_identifier` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `secret` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth2_client_id_idx` (`client_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_oauth2_clients`
--

LOCK TABLES `oc_oauth2_clients` WRITE;
/*!40000 ALTER TABLE `oc_oauth2_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_oauth2_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_preferences`
--

DROP TABLE IF EXISTS `oc_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_preferences` (
  `userid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `appid` varchar(32) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`userid`,`appid`,`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_preferences`
--

LOCK TABLES `oc_preferences` WRITE;
/*!40000 ALTER TABLE `oc_preferences` DISABLE KEYS */;
INSERT INTO `oc_preferences` VALUES ('atlas','activity','configured','yes'),('atlas','avatar','generated','true'),('atlas','core','lang','ru'),('atlas','core','templateDirectory','Шаблоны/'),('atlas','core','timezone','Europe/Moscow'),('atlas','dashboard','firstRun','0'),('atlas','firstrunwizard','apphint','18'),('atlas','firstrunwizard','show','0'),('atlas','login','lastLogin','1666120859'),('atlas','login_token','H47ufs5zx11FNVBlanMZJCwAh29vBEf7','1666120857'),('atlas','login_token','eydNfzabUka9Ii4OoyXrjaD1rHTrZ+4N','1529666682'),('atlas','password_policy','failedLoginAttempts','0');
/*!40000 ALTER TABLE `oc_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_privacy_admins`
--

DROP TABLE IF EXISTS `oc_privacy_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_privacy_admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `displayname` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_privacy_admins`
--

LOCK TABLES `oc_privacy_admins` WRITE;
/*!40000 ALTER TABLE `oc_privacy_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_privacy_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_profile_config`
--

DROP TABLE IF EXISTS `oc_profile_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_profile_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `config` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profile_config_user_id_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_profile_config`
--

LOCK TABLES `oc_profile_config` WRITE;
/*!40000 ALTER TABLE `oc_profile_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_profile_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_properties`
--

DROP TABLE IF EXISTS `oc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_properties` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `propertypath` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `propertyname` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `propertyvalue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `property_index` (`userid`),
  KEY `properties_path_index` (`userid`,`propertypath`),
  KEY `properties_pathonly_index` (`propertypath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_properties`
--

LOCK TABLES `oc_properties` WRITE;
/*!40000 ALTER TABLE `oc_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ratelimit_entries`
--

DROP TABLE IF EXISTS `oc_ratelimit_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ratelimit_entries` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hash` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `delete_after` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ratelimit_hash` (`hash`),
  KEY `ratelimit_delete_after` (`delete_after`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ratelimit_entries`
--

LOCK TABLES `oc_ratelimit_entries` WRITE;
/*!40000 ALTER TABLE `oc_ratelimit_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ratelimit_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_reactions`
--

DROP TABLE IF EXISTS `oc_reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_reactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned NOT NULL,
  `message_id` bigint unsigned NOT NULL,
  `actor_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `actor_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `reaction` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_reaction_unique` (`parent_id`,`actor_type`,`actor_id`,`reaction`),
  KEY `comment_reaction` (`reaction`),
  KEY `comment_reaction_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_reactions`
--

LOCK TABLES `oc_reactions` WRITE;
/*!40000 ALTER TABLE `oc_reactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_recent_contact`
--

DROP TABLE IF EXISTS `oc_recent_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_recent_contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `actor_uid` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `uid` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `federated_cloud_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `card` longblob NOT NULL,
  `last_contact` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recent_contact_actor_uid` (`actor_uid`),
  KEY `recent_contact_id_uid` (`id`,`actor_uid`),
  KEY `recent_contact_uid` (`uid`),
  KEY `recent_contact_email` (`email`),
  KEY `recent_contact_fed_id` (`federated_cloud_id`),
  KEY `recent_contact_last_contact` (`last_contact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_recent_contact`
--

LOCK TABLES `oc_recent_contact` WRITE;
/*!40000 ALTER TABLE `oc_recent_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_recent_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_schedulingobjects`
--

DROP TABLE IF EXISTS `oc_schedulingobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_schedulingobjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `lastmodified` int unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schedulobj_principuri_index` (`principaluri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_schedulingobjects`
--

LOCK TABLES `oc_schedulingobjects` WRITE;
/*!40000 ALTER TABLE `oc_schedulingobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_schedulingobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share`
--

DROP TABLE IF EXISTS `oc_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_share` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `share_type` smallint NOT NULL DEFAULT '0',
  `share_with` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `uid_owner` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `uid_initiator` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `parent` bigint DEFAULT NULL,
  `item_type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `item_source` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `item_target` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `file_source` bigint DEFAULT NULL,
  `file_target` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `permissions` smallint NOT NULL DEFAULT '0',
  `stime` bigint NOT NULL DEFAULT '0',
  `accepted` smallint NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `token` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `mail_send` smallint NOT NULL DEFAULT '0',
  `share_name` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `password_by_talk` tinyint(1) DEFAULT '0',
  `note` longtext COLLATE utf8mb4_bin,
  `hide_download` smallint DEFAULT '0',
  `label` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `attributes` json DEFAULT NULL,
  `password_expiration_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_share_type_index` (`item_type`,`share_type`),
  KEY `file_source_index` (`file_source`),
  KEY `token_index` (`token`),
  KEY `share_with_index` (`share_with`),
  KEY `parent_index` (`parent`),
  KEY `owner_index` (`uid_owner`),
  KEY `initiator_index` (`uid_initiator`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share`
--

LOCK TABLES `oc_share` WRITE;
/*!40000 ALTER TABLE `oc_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share_external`
--

DROP TABLE IF EXISTS `oc_share_external`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_share_external` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent` bigint DEFAULT '-1',
  `share_type` int DEFAULT NULL,
  `remote` varchar(512) COLLATE utf8mb4_bin NOT NULL,
  `remote_id` varchar(255) COLLATE utf8mb4_bin DEFAULT '',
  `share_token` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(4000) COLLATE utf8mb4_bin NOT NULL,
  `owner` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `user` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `mountpoint` varchar(4000) COLLATE utf8mb4_bin NOT NULL,
  `mountpoint_hash` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `accepted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sh_external_mp` (`user`,`mountpoint_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share_external`
--

LOCK TABLES `oc_share_external` WRITE;
/*!40000 ALTER TABLE `oc_share_external` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share_external` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages`
--

DROP TABLE IF EXISTS `oc_storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_storages` (
  `numeric_id` bigint NOT NULL AUTO_INCREMENT,
  `id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `available` int NOT NULL DEFAULT '1',
  `last_checked` int DEFAULT NULL,
  PRIMARY KEY (`numeric_id`),
  UNIQUE KEY `storages_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages`
--

LOCK TABLES `oc_storages` WRITE;
/*!40000 ALTER TABLE `oc_storages` DISABLE KEYS */;
INSERT INTO `oc_storages` VALUES (1,'local::/var/www/html/data/',1,NULL),(2,'home::atlas',1,NULL);
/*!40000 ALTER TABLE `oc_storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages_credentials`
--

DROP TABLE IF EXISTS `oc_storages_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_storages_credentials` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `identifier` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `credentials` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stocred_ui` (`user`,`identifier`),
  KEY `stocred_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages_credentials`
--

LOCK TABLES `oc_storages_credentials` WRITE;
/*!40000 ALTER TABLE `oc_storages_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_storages_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag`
--

DROP TABLE IF EXISTS `oc_systemtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `visibility` smallint NOT NULL DEFAULT '1',
  `editable` smallint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_ident` (`name`,`visibility`,`editable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag`
--

LOCK TABLES `oc_systemtag` WRITE;
/*!40000 ALTER TABLE `oc_systemtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_group`
--

DROP TABLE IF EXISTS `oc_systemtag_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag_group` (
  `systemtagid` bigint unsigned NOT NULL DEFAULT '0',
  `gid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`gid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_group`
--

LOCK TABLES `oc_systemtag_group` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_object_mapping`
--

DROP TABLE IF EXISTS `oc_systemtag_object_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag_object_mapping` (
  `objectid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `objecttype` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `systemtagid` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`objecttype`,`objectid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_object_mapping`
--

LOCK TABLES `oc_systemtag_object_mapping` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_documents`
--

DROP TABLE IF EXISTS `oc_text_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_documents` (
  `id` bigint unsigned NOT NULL,
  `current_version` bigint unsigned DEFAULT '0',
  `last_saved_version` bigint unsigned DEFAULT '0',
  `last_saved_version_time` bigint unsigned NOT NULL,
  `last_saved_version_etag` varchar(64) COLLATE utf8mb4_bin DEFAULT '',
  `base_version_etag` varchar(64) COLLATE utf8mb4_bin DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_documents`
--

LOCK TABLES `oc_text_documents` WRITE;
/*!40000 ALTER TABLE `oc_text_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_sessions`
--

DROP TABLE IF EXISTS `oc_text_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guest_name` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `color` varchar(7) COLLATE utf8mb4_bin DEFAULT NULL,
  `token` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `document_id` bigint NOT NULL,
  `last_contact` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rd_session_token_idx` (`token`),
  KEY `ts_lastcontact` (`last_contact`),
  KEY `ts_docid_lastcontact` (`document_id`,`last_contact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_sessions`
--

LOCK TABLES `oc_text_sessions` WRITE;
/*!40000 ALTER TABLE `oc_text_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_steps`
--

DROP TABLE IF EXISTS `oc_text_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_steps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `document_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  `version` bigint unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rd_steps_did_idx` (`document_id`),
  KEY `rd_steps_version_idx` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_steps`
--

LOCK TABLES `oc_text_steps` WRITE;
/*!40000 ALTER TABLE `oc_text_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_trusted_servers`
--

DROP TABLE IF EXISTS `oc_trusted_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_trusted_servers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(512) COLLATE utf8mb4_bin NOT NULL,
  `url_hash` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `token` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `shared_secret` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` int NOT NULL DEFAULT '2',
  `sync_token` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_hash` (`url_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_trusted_servers`
--

LOCK TABLES `oc_trusted_servers` WRITE;
/*!40000 ALTER TABLE `oc_trusted_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_trusted_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_twofactor_backupcodes`
--

DROP TABLE IF EXISTS `oc_twofactor_backupcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_twofactor_backupcodes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `code` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `used` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `twofactor_backupcodes_uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_twofactor_backupcodes`
--

LOCK TABLES `oc_twofactor_backupcodes` WRITE;
/*!40000 ALTER TABLE `oc_twofactor_backupcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_twofactor_backupcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_twofactor_providers`
--

DROP TABLE IF EXISTS `oc_twofactor_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_twofactor_providers` (
  `provider_id` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `enabled` smallint NOT NULL,
  PRIMARY KEY (`provider_id`,`uid`),
  KEY `twofactor_providers_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_twofactor_providers`
--

LOCK TABLES `oc_twofactor_providers` WRITE;
/*!40000 ALTER TABLE `oc_twofactor_providers` DISABLE KEYS */;
INSERT INTO `oc_twofactor_providers` VALUES ('backup_codes','atlas',0);
/*!40000 ALTER TABLE `oc_twofactor_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_status`
--

DROP TABLE IF EXISTS `oc_user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_user_status` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status_timestamp` int unsigned NOT NULL,
  `is_user_defined` tinyint(1) DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `custom_icon` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `custom_message` longtext COLLATE utf8mb4_bin,
  `clear_at` int unsigned DEFAULT NULL,
  `is_backup` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_status_uid_ix` (`user_id`),
  KEY `user_status_clr_ix` (`clear_at`),
  KEY `user_status_tstmp_ix` (`status_timestamp`),
  KEY `user_status_iud_ix` (`is_user_defined`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_status`
--

LOCK TABLES `oc_user_status` WRITE;
/*!40000 ALTER TABLE `oc_user_status` DISABLE KEYS */;
INSERT INTO `oc_user_status` VALUES (1,'atlas','online',1666125495,0,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `oc_user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_transfer_owner`
--

DROP TABLE IF EXISTS `oc_user_transfer_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_user_transfer_owner` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_user` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_user` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `file_id` bigint NOT NULL,
  `node_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_transfer_owner`
--

LOCK TABLES `oc_user_transfer_owner` WRITE;
/*!40000 ALTER TABLE `oc_user_transfer_owner` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_user_transfer_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_users`
--

DROP TABLE IF EXISTS `oc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_users` (
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `displayname` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `uid_lower` varchar(64) COLLATE utf8mb4_bin DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `user_uid_lower` (`uid_lower`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_users`
--

LOCK TABLES `oc_users` WRITE;
/*!40000 ALTER TABLE `oc_users` DISABLE KEYS */;
INSERT INTO `oc_users` VALUES ('atlas',NULL,'3|$argon2id$v=19$m=65536,t=4,p=1$Q3UuTEFWam0uMlRGaEFoaQ$O9KBsh4Ila3vizqkITcQSLMgUT1bX+KsTR5Lt+btts0','atlas');
/*!40000 ALTER TABLE `oc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory`
--

DROP TABLE IF EXISTS `oc_vcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_vcategory` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `category` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uid_index` (`uid`),
  KEY `type_index` (`type`),
  KEY `category_index` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory`
--

LOCK TABLES `oc_vcategory` WRITE;
/*!40000 ALTER TABLE `oc_vcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory_to_object`
--

DROP TABLE IF EXISTS `oc_vcategory_to_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_vcategory_to_object` (
  `objid` bigint unsigned NOT NULL DEFAULT '0',
  `categoryid` bigint unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryid`,`objid`,`type`),
  KEY `vcategory_objectd_index` (`objid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory_to_object`
--

LOCK TABLES `oc_vcategory_to_object` WRITE;
/*!40000 ALTER TABLE `oc_vcategory_to_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory_to_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_webauthn`
--

DROP TABLE IF EXISTS `oc_webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `public_key_credential_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webauthn_uid` (`uid`),
  KEY `webauthn_publicKeyCredentialId` (`public_key_credential_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_webauthn`
--

LOCK TABLES `oc_webauthn` WRITE;
/*!40000 ALTER TABLE `oc_webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_whats_new`
--

DROP TABLE IF EXISTS `oc_whats_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_whats_new` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '11',
  `etag` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `last_check` int unsigned NOT NULL DEFAULT '0',
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `version` (`version`),
  KEY `version_etag_idx` (`version`,`etag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_whats_new`
--

LOCK TABLES `oc_whats_new` WRITE;
/*!40000 ALTER TABLE `oc_whats_new` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_whats_new` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-18 20:48:05
